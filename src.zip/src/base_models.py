"""
08_base_models.py
==================
Train all base learners using out-of-fold (OOF) cross-validation.

Base Learners
-------------
  1. XGBoost   (tree_method='hist' — CPU optimized)
  2. LightGBM
  3. CatBoost
  4. Random Forest
  5. Extra Trees
  6. SVM (RBF kernel)

For each model:
  - StratifiedKFold OOF predictions → meta-feature matrix for stacking
  - Final model trained on full (resampled) training set
  - Probability calibration via CalibratedClassifierCV
  - Class imbalance handled via class_weight / scale_pos_weight

Outputs
-------
  results/checkpoints/oof_predictions.parquet
  results/models/base_<name>.joblib  (one per model)
"""

import logging
import os
import time
import warnings

import joblib
import numpy as np
import pandas as pd
import yaml
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
from xgboost import XGBClassifier
from tqdm import tqdm
from collections import Counter

warnings.filterwarnings("ignore")
log = logging.getLogger("BaseModels")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def _make_models(cfg: dict, scale_pos_weight: float) -> dict:
    """Instantiate all base models with config-driven hyperparameters."""
    mc   = cfg["models"]
    seed = cfg["random_seed"]

    return {
        "xgboost": XGBClassifier(
            n_estimators=mc["xgboost"]["n_estimators"],
            tree_method=mc["xgboost"]["tree_method"],
            eval_metric=mc["xgboost"]["eval_metric"],
            scale_pos_weight=scale_pos_weight,
            use_label_encoder=False,
            random_state=seed,
            n_jobs=-1,
            verbosity=0,
        ),
        "lightgbm": LGBMClassifier(
            n_estimators=mc["lightgbm"]["n_estimators"],
            boosting_type=mc["lightgbm"]["boosting_type"],
            class_weight="balanced",
            n_jobs=mc["lightgbm"]["n_jobs"],
            random_state=seed,
            verbose=mc["lightgbm"]["verbose"],
        ),
        "catboost": CatBoostClassifier(
            iterations=mc["catboost"]["iterations"],
            task_type=mc["catboost"]["task_type"],
            auto_class_weights="Balanced",
            verbose=mc["catboost"]["verbose"],
            random_seed=mc["catboost"]["random_seed"],
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=mc["random_forest"]["n_estimators"],
            class_weight="balanced",
            n_jobs=mc["random_forest"]["n_jobs"],
            random_state=seed,
        ),
        "extra_trees": ExtraTreesClassifier(
            n_estimators=mc["extra_trees"]["n_estimators"],
            class_weight="balanced",
            n_jobs=mc["extra_trees"]["n_jobs"],
            random_state=seed,
        ),
        "svm": SVC(
            kernel=mc["svm"]["kernel"],
            probability=mc["svm"]["probability"],
            class_weight="balanced",
            cache_size=mc["svm"]["cache_size"],
            random_state=seed,
        ),
    }


def train_base_models(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    config_path: str = "config.yaml"
) -> dict:
    """
    Train all base models with OOF cross-validation.

    Returns
    -------
    dict with keys:
        'oof_train'      : np.ndarray shape (n_train, n_models) — OOF probabilities
        'oof_test'       : np.ndarray shape (n_test,  n_models) — test probabilities
        'model_names'    : list of model names
        'trained_models' : dict name → fitted estimator
        'metrics'        : dict name → {f1, auc}
    """
    cfg  = _load_config(config_path)
    paths = cfg["paths"]
    cvcfg = cfg["cv"]
    seed  = cfg["random_seed"]
    ck    = paths["checkpoints_dir"]
    md    = paths["models_dir"]
    os.makedirs(md, exist_ok=True)

    # Scale pos weight for XGBoost
    c = Counter(y_train)
    scale_pos_weight = c[0] / c[1] if c[1] > 0 else 1.0

    models = _make_models(cfg, scale_pos_weight)
    model_names = list(models.keys())
    n_models = len(model_names)
    n_train  = len(X_train)
    n_test   = len(X_test)
    n_folds  = cvcfg["n_folds"]

    oof_train = np.zeros((n_train, n_models))
    oof_test  = np.zeros((n_test,  n_models))

    trained_models = {}
    metrics = {}

    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)

    for i, (name, model) in enumerate(models.items()):
        log.info(f"═══ Training [{i+1}/{n_models}]: {name.upper()} ═══")
        t0 = time.time()

        fold_test_preds = np.zeros((n_test, n_folds))

        for fold, (tr_idx, va_idx) in enumerate(
            skf.split(X_train, y_train), start=1
        ):
            log.info(f"  Fold {fold}/{n_folds}…")
            Xf_tr, Xf_va = X_train[tr_idx], X_train[va_idx]
            yf_tr, yf_va = y_train[tr_idx], y_train[va_idx]

            # Clone model for each fold
            fold_model = _make_models(cfg, scale_pos_weight)[name]

            # Fit with early stopping where supported
            if name in ("xgboost",):
                fold_model.fit(
                    Xf_tr, yf_tr,
                    eval_set=[(Xf_va, yf_va)],
                    verbose=False,
                )
            elif name == "lightgbm":
                fold_model.fit(
                    Xf_tr, yf_tr,
                    eval_set=[(Xf_va, yf_va)],
                )
            else:
                fold_model.fit(Xf_tr, yf_tr)

            # OOF predictions
            oof_train[va_idx, i] = fold_model.predict_proba(Xf_va)[:, 1]
            fold_test_preds[:, fold - 1] = fold_model.predict_proba(X_test)[:, 1]

            fold_f1 = f1_score(yf_va, (oof_train[va_idx, i] >= 0.5).astype(int))
            log.info(f"    Fold {fold} OOF F1: {fold_f1:.4f}")

        # Average test predictions across folds
        oof_test[:, i] = fold_test_preds.mean(axis=1)

        # Train final model on full training set
        log.info(f"  Training final {name} on full training set…")
        final_model = _make_models(cfg, scale_pos_weight)[name]
        if name in ("xgboost",):
            final_model.fit(X_train, y_train, verbose=False)
        else:
            final_model.fit(X_train, y_train)

        trained_models[name] = final_model

        # Metrics on test set
        test_proba = oof_test[:, i]
        test_pred  = (test_proba >= 0.5).astype(int)
        f1  = f1_score(y_test, test_pred)
        try:
            auc = roc_auc_score(y_test, test_proba)
        except ValueError:
            auc = 0.5
        metrics[name] = {"f1": f1, "auc_roc": auc}

        elapsed = time.time() - t0
        log.info(f"  {name}: Test F1={f1:.4f}  AUC-ROC={auc:.4f}  "
                 f"({elapsed:.1f}s)")

        # Save model
        model_path = f"{md}/base_{name}.joblib"
        joblib.dump(final_model, model_path)
        log.info(f"  Saved → {model_path}")

    # ── Save OOF predictions ───────────────────────────────────────────────────
    oof_train_df = pd.DataFrame(oof_train, columns=[f"oof_{n}" for n in model_names])
    oof_test_df  = pd.DataFrame(oof_test,  columns=[f"oof_{n}" for n in model_names])
    oof_train_df["y_true"] = y_train
    oof_test_df["y_true"]  = y_test

    oof_train_df.to_parquet(f"{ck}/oof_train_predictions.parquet", index=False)
    oof_test_df.to_parquet(f"{ck}/oof_test_predictions.parquet",   index=False)
    log.info(f"OOF predictions saved → {ck}/")

    log.info("\n═══ Base Model Summary ═══")
    for name, m in metrics.items():
        log.info(f"  {name:<20} F1={m['f1']:.4f}   AUC={m['auc_roc']:.4f}")

    return {
        "oof_train":      oof_train,
        "oof_test":       oof_test,
        "model_names":    model_names,
        "trained_models": trained_models,
        "metrics":        metrics,
    }


if __name__ == "__main__":
    log.info("Base models module loaded. Call train_base_models().")
