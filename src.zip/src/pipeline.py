"""
pipeline.py
===============
End-to-end orchestration of the Hybrid Fraud Detection System.

Pipeline Steps
--------------
  Step 01 — Load & preprocess data
  Step 02 — Build graph & compute SNA features
  Step 03 — Generate Node2Vec embeddings
  Step 04 — Engineer temporal features
  Step 05 — Run Louvain community detection
  Step 06 — Fuse all feature streams
  Step 07 — Handle class imbalance (SMOTE-ENN)
  Step 08 — Hyperparameter tuning (Optuna)
  Step 09 — Train base models (OOF)
  Step 10 — Train stacking ensemble (MLP + LogReg)
  Step 11 — Build & save final Hybrid Model
  Step 12 — Run full evaluation & generate plots

Checkpointing
-------------
  Each step saves its output to results/checkpoints/.
  Completed steps are SKIPPED on re-run automatically.
  Delete a checkpoint file to force re-run of a step.

Usage
-----
  python Main_FDS.py                    # full pipeline
  python Main_FDS.py --skip-node2vec    # skip Node2Vec (use if checkpoint exists)
  python Main_FDS.py --only-eval        # only run evaluation on saved model
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
import yaml

# ── Setup logging to file + console ───────────────────────────────────────────
os.makedirs("results/logs", exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("results/logs/pipeline.log", mode="a"),
    ]
)
log = logging.getLogger("Pipeline")


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def _checkpoint_exists(ck: str, filename: str) -> bool:
    return os.path.exists(os.path.join(ck, filename))


def _step_header(n: int, title: str):
    log.info("")
    log.info("=" * 70)
    log.info(f"  STEP {n:02d}: {title}")
    log.info("=" * 70)


# ── Pipeline ───────────────────────────────────────────────────────────────────

def run_pipeline(config_path: str = "config.yaml", args=None):
    t_start = time.time()
    cfg = _load_config(config_path)
    ck  = cfg["paths"]["checkpoints_dir"]
    os.makedirs(ck, exist_ok=True)

    skip_node2vec = getattr(args, "skip_node2vec", False)
    only_eval     = getattr(args, "only_eval", False)

    log.info("╔══════════════════════════════════════════════════════════════╗")
    log.info("║  HYBRID FRAUD DETECTION SYSTEM — Elliptic Bitcoin Dataset   ║")
    log.info("║  Journal-Quality Pipeline v1.0                               ║")
    log.info("╚══════════════════════════════════════════════════════════════╝")

    # ── STEP 01: Data Loading ─────────────────────────────────────────────────
    _step_header(1, "Data Loading & Preprocessing")
    if not _checkpoint_exists(ck, "train_data.parquet"):
        from src.data_loader import load_and_preprocess
        data = load_and_preprocess(config_path)
    else:
        log.info("  [SKIP] Checkpoint found: train_data.parquet")
        data = {
            "train":        pd.read_parquet(f"{ck}/train_data.parquet"),
            "test":         pd.read_parquet(f"{ck}/test_data.parquet"),
            "edges":        pd.read_parquet(f"{ck}/edges.parquet"),
            "feature_cols": pd.read_csv(f"{ck}/feature_cols.csv")["col"].tolist(),
        }

    # ── STEP 02: Graph & SNA Features ────────────────────────────────────────
    _step_header(2, "Graph Construction & SNA Features")
    if not _checkpoint_exists(ck, "sna_features.parquet"):
        from src.graph_builder import build_graph_and_sna
        sna_df = build_graph_and_sna(config_path)
    else:
        log.info("  [SKIP] Checkpoint found: sna_features.parquet")

    # ── STEP 03: Node2Vec Embeddings ──────────────────────────────────────────
    _step_header(3, "Node2Vec Graph Embeddings")
    if not _checkpoint_exists(ck, "node2vec_embeddings.parquet") and not skip_node2vec:
        from src.node2vec_embeddings import generate_node2vec_embeddings
        emb_df = generate_node2vec_embeddings(config_path)
    elif skip_node2vec and not _checkpoint_exists(ck, "node2vec_embeddings.parquet"):
        log.warning("  [SKIP] Node2Vec skipped — creating zero embeddings placeholder")
        all_ids = pd.concat([
            data["train"][["txId"]], data["test"][["txId"]]
        ]).drop_duplicates()
        dim = cfg["node2vec"]["dimensions"]
        zero_emb = pd.DataFrame(
            np.zeros((len(all_ids), dim)),
            columns=[f"n2v_{i}" for i in range(dim)]
        )
        zero_emb.insert(0, "txId", all_ids["txId"].values)
        zero_emb.to_parquet(f"{ck}/node2vec_embeddings.parquet", index=False)
    else:
        log.info("  [SKIP] Checkpoint found: node2vec_embeddings.parquet")

    # ── STEP 04: Temporal Features ────────────────────────────────────────────
    _step_header(4, "Temporal Feature Engineering")
    if not _checkpoint_exists(ck, "temporal_features.parquet"):
        from src.temporal_features import build_temporal_features
        temp_df = build_temporal_features(config_path)
    else:
        log.info("  [SKIP] Checkpoint found: temporal_features.parquet")

    # ── STEP 05: Community Detection ──────────────────────────────────────────
    _step_header(5, "Louvain Community Detection")
    if not _checkpoint_exists(ck, "community_features.parquet"):
        from src.community_detection import detect_communities_and_features
        comm_df = detect_communities_and_features(config_path)
    else:
        log.info("  [SKIP] Checkpoint found: community_features.parquet")

    # ── STEP 06: Feature Fusion ───────────────────────────────────────────────
    _step_header(6, "Feature Fusion & Selection")
    if not _checkpoint_exists(ck, "X_train_fused.parquet"):
        from src.feature_fusion import fuse_features
        X_train_df, X_test_df, y_train_s, y_test_s, feature_names = fuse_features(config_path)
        X_train, X_test = X_train_df.values, X_test_df.values
        y_train, y_test = y_train_s.values, y_test_s.values
    else:
        log.info("  [SKIP] Checkpoint found: X_train_fused.parquet")
        fused_train = pd.read_parquet(f"{ck}/X_train_fused.parquet")
        fused_test  = pd.read_parquet(f"{ck}/X_test_fused.parquet")
        feature_names = pd.read_csv(f"{ck}/selected_feature_names.csv")["feature"].tolist()
        y_train = fused_train["label"].values
        y_test  = fused_test["label"].values
        X_train = fused_train.drop(columns=["txId","label"]).values
        X_test  = fused_test.drop(columns=["txId","label"]).values

    if only_eval:
        log.info("  [--only-eval] Jumping to evaluation…")
        _run_eval_only(cfg, feature_names, X_test, y_test, ck)
        return predictor if 'predictor' in locals() else None, None

    # ── STEP 07: Imbalance Handling ───────────────────────────────────────────
    _step_header(7, "Class Imbalance Handling (SMOTE-ENN)")
    from src.imbalance_handler import resample_training_data
    X_train_res, y_train_res = resample_training_data(X_train, y_train, config_path)

    # ── STEP 08: Hyperparameter Tuning ────────────────────────────────────────
    _step_header(8, "Hyperparameter Tuning (Optuna)")
    best_params_path = "results/reports/optuna_best_params.yaml"
    if not os.path.exists(best_params_path):
        from src.hyperparameter_tuning import run_hyperparameter_tuning, build_tuned_models
        best_params = run_hyperparameter_tuning(X_train_res, y_train_res, config_path)
    else:
        log.info("  [SKIP] Optuna results found — loading best params")
        with open(best_params_path, "r") as f:
            best_params = yaml.safe_load(f)

    # ── STEP 09: Train Base Models ────────────────────────────────────────────
    _step_header(9, "Base Model Training (OOF Cross-Validation)")
    if not _checkpoint_exists(ck, "oof_train_predictions.parquet"):
        from src.base_models import train_base_models
        base_results = train_base_models(
            X_train_res, y_train_res, X_test, y_test, config_path
        )
    else:
        log.info("  [SKIP] OOF predictions found — loading models")
        from src.base_models import _make_models
        from collections import Counter
        c = Counter(y_train_res)
        spw = c[0] / c[1] if c[1] > 0 else 1.0
        tmp_models = {}
        for name in ["xgboost","lightgbm","catboost","random_forest","extra_trees","svm"]:
            mpath = f"results/models/base_{name}.joblib"
            if os.path.exists(mpath):
                tmp_models[name] = joblib.load(mpath)
        oof_tr = pd.read_parquet(f"{ck}/oof_train_predictions.parquet")
        oof_te = pd.read_parquet(f"{ck}/oof_test_predictions.parquet")
        oof_cols = [c for c in oof_tr.columns if c.startswith("oof_")]
        base_results = {
            "oof_train":      oof_tr[oof_cols].values,
            "oof_test":       oof_te[oof_cols].values,
            "model_names":    [c.replace("oof_","") for c in oof_cols],
            "trained_models": tmp_models,
            "metrics":        {},
        }

    # ── STEP 10: Stacking Ensemble ────────────────────────────────────────────
    _step_header(10, "Stacking Ensemble (MLP + Logistic Regression)")
    if not _checkpoint_exists(ck, "stacked_predictions.parquet"):
        from src.stacking_ensemble import train_stacking_ensemble
        stack_results = train_stacking_ensemble(config_path)
    else:
        log.info("  [SKIP] Stacked predictions found — loading models")
        stk = pd.read_parquet(f"{ck}/stacked_predictions.parquet")
        from src.stacking_ensemble import MetaMLP
        mlp_cfg = cfg["mlp"]
        n_base  = base_results["oof_train"].shape[1]
        mlp     = MetaMLP(n_base, mlp_cfg["hidden_dims"], mlp_cfg["dropout"])
        mlp.load_state_dict(torch.load("results/models/meta_mlp.pt"))
        mlp.eval()
        lr_meta = joblib.load("results/models/meta_logreg.joblib")
        scaler  = joblib.load("results/models/meta_scaler.joblib")
        stack_results = {
            "mlp":              mlp,
            "logreg":           lr_meta,
            "meta_scaler":      scaler,
            "blend_proba_test": stk["blend_proba"].values,
            "y_test":           stk["y_true"].values,
            "metrics": {},
        }

    # ── STEP 11: Hybrid Model ─────────────────────────────────────────────────
    _step_header(11, "Building & Saving Final Hybrid Model")
    from src.hybrid_model import build_hybrid_model
    predictor = build_hybrid_model(
        base_results   = base_results,
        stack_results  = stack_results,
        X_test         = X_test,
        y_test         = y_test,
        feature_names  = feature_names,
        config_path    = config_path,
    )

    hybrid_proba      = predictor.predict_proba(X_test)
    optimal_threshold = predictor.optimal_threshold

    # ── STEP 12: Evaluation ───────────────────────────────────────────────────
    _step_header(12, "Full Evaluation & Publication Figures")
    from src.evaluation import run_full_evaluation
    metrics_df = run_full_evaluation(
        base_results       = base_results,
        stack_results      = stack_results,
        hybrid_proba       = hybrid_proba,
        X_test             = X_test,
        y_test             = y_test,
        feature_names      = feature_names,
        optimal_threshold  = optimal_threshold,
        config_path        = config_path,
    )

    # ── Summary ───────────────────────────────────────────────────────────────
    elapsed = time.time() - t_start
    h, m, s = int(elapsed//3600), int((elapsed%3600)//60), int(elapsed%60)

    log.info("")
    log.info("╔══════════════════════════════════════════════════════════════╗")
    log.info("║                    PIPELINE COMPLETE ✅                      ║")
    log.info(f"║   Total time: {h}h {m}m {s}s{' '*44}║")
    log.info("║                                                              ║")
    log.info("║   Key outputs:                                               ║")
    log.info("║   • results/models/HYBRID_FINAL_MODEL.joblib                ║")
    log.info("║   • results/figures/*.pdf  (10 publication figures)         ║")
    log.info("║   • results/reports/evaluation_summary.txt                  ║")
    log.info("║   • results/reports/metrics_all_models.csv                  ║")
    log.info("╚══════════════════════════════════════════════════════════════╝")

    hybrid_row = metrics_df[metrics_df["model"] == "HYBRID (Final)"]
    if not hybrid_row.empty:
        r = hybrid_row.iloc[0]
        log.info(f"\nHYBRID FINAL MODEL METRICS:")
        log.info(f"  F1 (Illicit): {r['f1_illicit']:.4f}")
        log.info(f"  AUC-ROC:      {r['auc_roc']:.4f}")
        log.info(f"  AUC-PR:       {r['auc_pr']:.4f}")
        log.info(f"  MCC:          {r['mcc']:.4f}")
        log.info(f"  Precision:    {r['precision']:.4f}")
        log.info(f"  Recall:       {r['recall']:.4f}")

    return predictor, metrics_df


def _run_eval_only(cfg, feature_names, X_test, y_test, ck):
    """Load saved models and run evaluation only."""
    from src.hybrid_model import HybridPredictor
    predictor = HybridPredictor.load("results/models/HYBRID_FINAL_MODEL.joblib")
    hybrid_proba = predictor.predict_proba(X_test)

    oof_te = pd.read_parquet(f"{ck}/oof_test_predictions.parquet")
    oof_cols = [c for c in oof_te.columns if c.startswith("oof_")]
    model_names = [c.replace("oof_","") for c in oof_cols]
    tmp_models = {}
    for name in model_names:
        mpath = f"results/models/base_{name}.joblib"
        if os.path.exists(mpath):
            tmp_models[name] = joblib.load(mpath)

    stk = pd.read_parquet(f"{ck}/stacked_predictions.parquet")

    from src.evaluation import run_full_evaluation
    run_full_evaluation(
        base_results = {
            "oof_train": None,
            "oof_test": oof_te[oof_cols].values,
            "model_names": model_names,
            "trained_models": tmp_models,
            "metrics": {},
        },
        stack_results = {"blend_proba_test": stk["blend_proba"].values, "metrics": {}},
        hybrid_proba       = hybrid_proba,
        X_test             = X_test,
        y_test             = y_test,
        feature_names      = feature_names,
        optimal_threshold  = predictor.optimal_threshold,
        config_path        = "config.yaml",
    )


# ── Argument parser ────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(description="Hybrid FDS Pipeline")
    parser.add_argument("--skip-node2vec", action="store_true",
                        help="Skip Node2Vec embedding generation")
    parser.add_argument("--only-eval", action="store_true",
                        help="Load saved models and run evaluation only")
    parser.add_argument("--config", default="config.yaml",
                        help="Path to config YAML file")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_pipeline(config_path=args.config, args=args)
