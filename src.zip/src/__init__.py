"""
src/__init__.py
Expose all pipeline modules with clean import aliases.
"""

# Module aliases to match pipeline imports
from src import \
    data_loader, \
    graph_builder, \
    node2vec_embeddings, \
    temporal_features, \
    community_detection, \
    feature_fusion, \
    imbalance_handler, \
    base_models, \
    stacking_ensemble, \
    hybrid_model, \
    hyperparameter_tuning, \
    evaluation
