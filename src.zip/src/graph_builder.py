"""
02_graph_builder.py
====================
Build a directed NetworkX graph from the Elliptic edge list and
compute Social Network Analysis (SNA) features per transaction node.

SNA Features Computed
---------------------
- in_degree, out_degree, total_degree
- in_degree_centrality, out_degree_centrality
- pagerank
- betweenness_centrality (approximate)
- clustering_coefficient (undirected projection)
- hub_score, authority_score (HITS)
- core_number (k-core decomposition)
"""

import logging
import os
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import yaml
from tqdm import tqdm

log = logging.getLogger("GraphBuilder")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def build_graph_and_sna(config_path: str = "config.yaml") -> pd.DataFrame:
    cfg = _load_config(config_path)
    paths  = cfg["paths"]
    gcfg   = cfg["graph"]
    ck     = paths["checkpoints_dir"]

    os.makedirs(ck, exist_ok=True)

    # ── Load edges ─────────────────────────────────────────────────────────────
    log.info("Loading edges from checkpoint…")
    edges = pd.read_parquet(f"{ck}/edges.parquet")
    log.info(f"Edges loaded: {len(edges):,}")

    # ── Build directed graph ───────────────────────────────────────────────────
    log.info("Building directed graph…")
    G = nx.from_pandas_edgelist(
        edges, source="txId1", target="txId2",
        create_using=nx.DiGraph()
    )
    log.info(f"Graph: {G.number_of_nodes():,} nodes | {G.number_of_edges():,} edges")

    all_nodes = list(G.nodes())

    # ── SNA feature computation ────────────────────────────────────────────────
    log.info("Computing in/out degree…")
    in_deg  = dict(G.in_degree())
    out_deg = dict(G.out_degree())

    log.info("Computing degree centrality…")
    in_deg_cent  = nx.in_degree_centrality(G)
    out_deg_cent = nx.out_degree_centrality(G)

    log.info("Computing PageRank…")
    pagerank = nx.pagerank(G, alpha=gcfg["pagerank_alpha"], max_iter=200)

    log.info(f"Computing approximate betweenness centrality (k={gcfg['betweenness_k']})…")
    k_val = min(gcfg["betweenness_k"], G.number_of_nodes())
    betweenness = nx.betweenness_centrality(
        G, k=k_val, normalized=True, seed=42
    )

    log.info("Computing clustering coefficient (undirected projection)…")
    G_undirected = G.to_undirected()
    clustering = nx.clustering(G_undirected)

    log.info("Computing HITS hub/authority scores…")
    try:
        hubs, authorities = nx.hits(G, max_iter=gcfg["hits_max_iter"], normalized=True)
    except nx.PowerIterationFailedConvergence:
        log.warning("HITS did not converge — using zeros")
        hubs       = {n: 0.0 for n in all_nodes}
        authorities = {n: 0.0 for n in all_nodes}

    log.info("Computing k-core number (undirected)…")
    core_num = nx.core_number(G_undirected)

    # ── Assemble feature DataFrame ─────────────────────────────────────────────
    log.info("Assembling SNA feature dataframe…")
    records = []
    for node in tqdm(all_nodes, desc="SNA assembly"):
        records.append({
            "txId":                  node,
            "sna_in_degree":         in_deg.get(node, 0),
            "sna_out_degree":        out_deg.get(node, 0),
            "sna_total_degree":      in_deg.get(node, 0) + out_deg.get(node, 0),
            "sna_in_deg_cent":       in_deg_cent.get(node, 0.0),
            "sna_out_deg_cent":      out_deg_cent.get(node, 0.0),
            "sna_pagerank":          pagerank.get(node, 0.0),
            "sna_betweenness":       betweenness.get(node, 0.0),
            "sna_clustering":        clustering.get(node, 0.0),
            "sna_hub_score":         hubs.get(node, 0.0),
            "sna_authority_score":   authorities.get(node, 0.0),
            "sna_core_number":       core_num.get(node, 0),
        })

    sna_df = pd.DataFrame(records)
    log.info(f"SNA features: {sna_df.shape}")

    # ── Save ───────────────────────────────────────────────────────────────────
    sna_df.to_parquet(f"{ck}/sna_features.parquet", index=False)
    log.info(f"SNA features saved → {ck}/sna_features.parquet")

    return sna_df


if __name__ == "__main__":
    sna_df = build_graph_and_sna()
    log.info("Graph building complete.")
