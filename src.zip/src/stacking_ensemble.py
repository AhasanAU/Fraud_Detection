"""
09_stacking_ensemble.py
========================
Build a two-level stacking ensemble:

Level 1 (Base Learners) → already computed OOF probabilities
Level 2 (Meta-Learners):
  A. MLP  — 3-layer neural network (PyTorch)
  B. Logistic Regression (calibrated, as reference)

Both meta-learners are trained on the OOF predictions from Level-1.
Final stacked prediction = 0.6 × MLP + 0.4 × LogReg (weighted blend).

MLP Architecture
----------------
  Input: n_base_models (probabilities from each base learner)
  → Linear(n_base, 256) → BatchNorm → LeakyReLU → Dropout(0.3)
  → Linear(256, 128)    → BatchNorm → LeakyReLU → Dropout(0.3)
  → Linear(128, 64)     → BatchNorm → LeakyReLU
  → Linear(64, 1)       → Sigmoid
"""

import logging
import os
import warnings

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import yaml
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset

def safe_roc_auc_score(y_true, y_proba):
    try:
        return roc_auc_score(y_true, y_proba)
    except ValueError:
        return 0.5

warnings.filterwarnings("ignore")
log = logging.getLogger("StackingEnsemble")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


# ── MLP Architecture ──────────────────────────────────────────────────────────

class MetaMLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dims: list, dropout: float):
        super().__init__()
        layers = []
        in_dim = input_dim
        for h in hidden_dims:
            layers += [
                nn.Linear(in_dim, h),
                nn.BatchNorm1d(h),
                nn.LeakyReLU(0.1),
                nn.Dropout(dropout),
            ]
            in_dim = h
        layers += [nn.Linear(in_dim, 1), nn.Sigmoid()]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(1)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def _train_mlp(
    X_tr: np.ndarray, y_tr: np.ndarray,
    X_va: np.ndarray, y_va: np.ndarray,
    cfg: dict
) -> MetaMLP:
    mlpcfg = cfg["mlp"]
    seed   = cfg["random_seed"]
    torch.manual_seed(seed)
    np.random.seed(seed)

    device = torch.device("cpu")
    n_pos  = y_tr.sum()
    n_neg  = len(y_tr) - n_pos
    pos_weight = torch.tensor([n_neg / max(n_pos, 1)], dtype=torch.float32)

    model = MetaMLP(X_tr.shape[1], mlpcfg["hidden_dims"], mlpcfg["dropout"]).to(device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = optim.AdamW(
        model.parameters(),
        lr=mlpcfg["learning_rate"],
        weight_decay=mlpcfg["weight_decay"]
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=mlpcfg["epochs"]
    )

    X_tr_t = torch.tensor(X_tr, dtype=torch.float32)
    y_tr_t = torch.tensor(y_tr, dtype=torch.float32)
    X_va_t = torch.tensor(X_va, dtype=torch.float32)
    y_va_t = torch.tensor(y_va, dtype=torch.float32)

    loader = DataLoader(
        TensorDataset(X_tr_t, y_tr_t),
        batch_size=mlpcfg["batch_size"],
        shuffle=True,
    )

    best_f1    = 0.0
    best_state = None
    patience   = mlpcfg["patience"]
    no_improve = 0

    for epoch in range(1, mlpcfg["epochs"] + 1):
        model.train()
        for Xb, yb in loader:
            optimizer.zero_grad()
            logits = model(Xb).unsqueeze(1)
            loss   = nn.BCEWithLogitsLoss(pos_weight=pos_weight)(logits.squeeze(), yb)
            loss.backward()
            optimizer.step()
        scheduler.step()

        # Validation
        model.eval()
        with torch.no_grad():
            val_proba = model(X_va_t).numpy()
        val_pred = (val_proba >= 0.5).astype(int)
        val_f1   = f1_score(y_va, val_pred, zero_division=0)

        if val_f1 > best_f1:
            best_f1    = val_f1
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience:
                log.info(f"    Early stopping at epoch {epoch} (best F1={best_f1:.4f})")
                break

        if epoch % 10 == 0:
            log.info(f"    Epoch {epoch}: val_F1={val_f1:.4f}  best={best_f1:.4f}")

    if best_state is not None:
        model.load_state_dict(best_state)
    return model


# ── Main ─────────────────────────────────────────────────────────────────────

def train_stacking_ensemble(config_path: str = "config.yaml") -> dict:
    cfg   = _load_config(config_path)
    paths = cfg["paths"]
    ck    = paths["checkpoints_dir"]
    md    = paths["models_dir"]
    seed  = cfg["random_seed"]
    os.makedirs(md, exist_ok=True)

    # ── Load OOF predictions ───────────────────────────────────────────────────
    log.info("Loading OOF predictions…")
    oof_train = pd.read_parquet(f"{ck}/oof_train_predictions.parquet")
    oof_test  = pd.read_parquet(f"{ck}/oof_test_predictions.parquet")

    oof_cols  = [c for c in oof_train.columns if c.startswith("oof_")]
    X_meta_tr = oof_train[oof_cols].values.astype(np.float32)
    y_meta_tr = oof_train["y_true"].values.astype(np.float32)
    X_meta_te = oof_test[oof_cols].values.astype(np.float32)
    y_meta_te = oof_test["y_true"].values.astype(np.float32)

    log.info(f"Meta-feature matrix: train={X_meta_tr.shape}, test={X_meta_te.shape}")
    log.info(f"Base models in stack: {oof_cols}")

    # ── Scale meta-features ────────────────────────────────────────────────────
    scaler = StandardScaler()
    X_meta_tr_sc = scaler.fit_transform(X_meta_tr)
    X_meta_te_sc = scaler.transform(X_meta_te)
    joblib.dump(scaler, f"{md}/meta_scaler.joblib")

    # ── A. Train MLP meta-learner ──────────────────────────────────────────────
    log.info("Training MLP meta-learner…")
    # Split validation from training meta-features (last 20%)
    n_val  = max(int(len(X_meta_tr_sc) * 0.2), 100)
    X_va   = X_meta_tr_sc[-n_val:]
    y_va   = y_meta_tr[-n_val:]
    X_tr_m = X_meta_tr_sc[:-n_val]
    y_tr_m = y_meta_tr[:-n_val]

    mlp = _train_mlp(X_tr_m, y_tr_m, X_va, y_va, cfg)

    # MLP predictions on full training + test meta-features
    mlp.eval()
    with torch.no_grad():
        mlp_proba_tr = mlp(torch.tensor(X_meta_tr_sc, dtype=torch.float32)).numpy()
        mlp_proba_te = mlp(torch.tensor(X_meta_te_sc, dtype=torch.float32)).numpy()

    mlp_f1  = f1_score(y_meta_te, (mlp_proba_te >= 0.5).astype(int))
    mlp_auc = safe_roc_auc_score(y_meta_te, mlp_proba_te)
    log.info(f"MLP meta-learner: F1={mlp_f1:.4f}  AUC={mlp_auc:.4f}")

    # Save MLP
    torch.save(mlp.state_dict(), f"{md}/meta_mlp.pt")
    log.info(f"MLP saved → {md}/meta_mlp.pt")

    # ── B. Train Logistic Regression meta-learner ──────────────────────────────
    log.info("Training Logistic Regression meta-learner…")
    lr_meta = LogisticRegression(
        class_weight="balanced",
        max_iter=1000,
        random_state=seed,
        solver="lbfgs"
    )
    lr_meta.fit(X_meta_tr_sc, y_meta_tr)

    lr_proba_te = lr_meta.predict_proba(X_meta_te_sc)[:, 1]
    lr_f1  = f1_score(y_meta_te, (lr_proba_te >= 0.5).astype(int))
    lr_auc = safe_roc_auc_score(y_meta_te, lr_proba_te)
    log.info(f"LogReg meta-learner: F1={lr_f1:.4f}  AUC={lr_auc:.4f}")

    joblib.dump(lr_meta, f"{md}/meta_logreg.joblib")

    # ── Blend: 0.6 MLP + 0.4 LogReg ───────────────────────────────────────────
    blend_proba_te = 0.6 * mlp_proba_te + 0.4 * lr_proba_te
    blend_f1  = f1_score(y_meta_te, (blend_proba_te >= 0.5).astype(int))
    blend_auc = safe_roc_auc_score(y_meta_te, blend_proba_te)
    log.info(f"Blended (0.6 MLP + 0.4 LR): F1={blend_f1:.4f}  AUC={blend_auc:.4f}")

    # ── Save stacked predictions ───────────────────────────────────────────────
    stack_out = pd.DataFrame({
        "mlp_proba":    mlp_proba_te,
        "lr_proba":     lr_proba_te,
        "blend_proba":  blend_proba_te,
        "y_true":       y_meta_te,
    })
    stack_out.to_parquet(f"{ck}/stacked_predictions.parquet", index=False)

    return {
        "mlp":            mlp,
        "logreg":         lr_meta,
        "meta_scaler":    scaler,
        "mlp_proba_test": mlp_proba_te,
        "lr_proba_test":  lr_proba_te,
        "blend_proba_test": blend_proba_te,
        "y_test":         y_meta_te,
        "metrics": {
            "mlp":   {"f1": mlp_f1,   "auc": mlp_auc},
            "logreg":{"f1": lr_f1,    "auc": lr_auc},
            "blend": {"f1": blend_f1, "auc": blend_auc},
        }
    }


if __name__ == "__main__":
    result = train_stacking_ensemble()
    log.info("Stacking ensemble complete.")
