"""
01_data_loader.py
=================
Load, merge and preprocess the Elliptic Bitcoin dataset.

Steps
-----
1. Load features CSV (no header) → assign column names
2. Load classes & edges CSVs
3. Merge features with labels; drop unknowns
4. Apply variance & correlation filtering (feature selection)
5. Temporal train / test split (t ≤ 34 = train, t ≥ 35 = test)
6. Save checkpoints as Parquet for downstream modules
"""

import logging
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr
from sklearn.preprocessing import StandardScaler

# ── Logger ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("DataLoader")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def _remove_low_variance(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
    """Drop columns with variance below threshold."""
    feature_cols = [c for c in df.columns if c not in ("txId", "time_step", "label")]
    variances = df[feature_cols].var()
    to_drop = variances[variances < threshold].index.tolist()
    log.info(f"Variance filter: dropping {len(to_drop)} low-variance columns")
    return df.drop(columns=to_drop)


def _remove_high_correlation(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
    """Drop highly correlated features (keep first occurrence)."""
    feature_cols = [c for c in df.columns if c not in ("txId", "time_step", "label")]
    corr_matrix = df[feature_cols].corr(method="pearson").abs()
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
    to_drop = [col for col in upper.columns if any(upper[col] > threshold)]
    log.info(f"Correlation filter (>{threshold}): dropping {len(to_drop)} columns")
    return df.drop(columns=to_drop)


# ── Main ─────────────────────────────────────────────────────────────────────

def load_and_preprocess(config_path: str = "config.yaml") -> dict:
    cfg = _load_config(config_path)
    paths = cfg["paths"]
    ds = cfg["dataset"]
    fs = cfg["feature_selection"]
    seed = cfg["random_seed"]

    os.makedirs(paths["checkpoints_dir"], exist_ok=True)

    # ── 1. Load features ──────────────────────────────────────────────────────
    log.info("Loading features CSV (this may take ~60 s for 200K rows × 166 cols)…")
    features_raw = pd.read_csv(paths["features_file"], header=None)
    n_rows, n_cols = features_raw.shape
    log.info(f"Features loaded: {n_rows:,} rows × {n_cols} cols")

    # Assign column names
    col_names = ["txId", "time_step"]
    local_start, local_end = ds["local_feature_cols"]
    agg_start, agg_end = ds["agg_feature_cols"]
    local_names  = [f"lf_{i}" for i in range(local_end - local_start + 1)]
    agg_names    = [f"af_{i}" for i in range(agg_end - agg_start + 1)]
    col_names   += local_names + agg_names
    # Pad if CSV has extra columns
    extra = n_cols - len(col_names)
    if extra > 0:
        col_names += [f"extra_{i}" for i in range(extra)]
    features_raw.columns = col_names[:n_cols]

    # ── 2. Load classes & edges ───────────────────────────────────────────────
    log.info("Loading classes and edges…")
    classes = pd.read_csv(paths["classes_file"])
    edges   = pd.read_csv(paths["edges_file"])

    # Standardise column names
    classes.columns = [c.strip().lower() for c in classes.columns]
    edges.columns   = [c.strip().lower() for c in edges.columns]
    # classes: txid, class
    classes.rename(columns={"txid": "txId"}, inplace=True, errors="ignore")
    edges.rename(columns={"txid1": "txId1", "txid2": "txId2"}, inplace=True, errors="ignore")

    log.info(f"Classes: {len(classes):,} rows  |  Edges: {len(edges):,} rows")

    # ── 3. Merge & filter ─────────────────────────────────────────────────────
    df = features_raw.merge(classes, on="txId", how="inner")
    log.info(f"Merged features and classes: {len(df):,} rows")

    # Map illicit=1, licit=0, unknown=-1
    df["label"] = df["class"].map({"1": 1, "2": 0, "unknown": -1, 1: 1, 2: 0, -1: -1}).fillna(-1).astype(int)
    df.drop(columns=["class"], inplace=True)

    illicit = (df["label"] == 1).sum()
    licit   = (df["label"] == 0).sum()
    unknown = (df["label"] == -1).sum()
    log.info(f"Class distribution — Illicit: {illicit:,} ({illicit/len(df)*100:.1f}%)  "
             f"Licit: {licit:,} ({licit/len(df)*100:.1f}%)  Unknown: {unknown:,} ({unknown/len(df)*100:.1f}%)")

    # ── 4. Feature selection — variance & correlation filtering ───────────────
    log.info("Applying low-variance filter…")
    df = _remove_low_variance(df, threshold=fs["variance_threshold"])
    log.info("Applying high-correlation filter…")
    df = _remove_high_correlation(df, threshold=fs["correlation_threshold"])

    feature_cols = [c for c in df.columns if c not in ("txId", "time_step", "label")]
    log.info(f"Features after selection: {len(feature_cols)}")

    # ── 5. Temporal train / test split ────────────────────────────────────────
    train_max = ds["train_timestep_max"]
    test_min  = ds["test_timestep_min"]
    df_train = df[df["time_step"] <= train_max].copy()
    df_test  = df[df["time_step"] >= test_min].copy()

    log.info(f"Train set (t ≤ {train_max}): {len(df_train):,} rows  "
             f"| illicit: {df_train['label'].sum():,}")
    log.info(f"Test  set (t ≥ {test_min}): {len(df_test):,} rows  "
             f"| illicit: {df_test['label'].sum():,}")

    # ── 6. Save checkpoints ───────────────────────────────────────────────────
    ck = paths["checkpoints_dir"]
    df_train.to_parquet(f"{ck}/train_data.parquet", index=False)
    df_test.to_parquet(f"{ck}/test_data.parquet", index=False)
    edges.to_parquet(f"{ck}/edges.parquet", index=False)
    # Save column lists for downstream use
    pd.Series(feature_cols).to_csv(f"{ck}/feature_cols.csv", index=False, header=["col"])
    log.info(f"Checkpoints saved → {ck}/")

    return {
        "train": df_train,
        "test": df_test,
        "edges": edges,
        "feature_cols": feature_cols,
    }


if __name__ == "__main__":
    result = load_and_preprocess()
    log.info("Data loading complete.")
