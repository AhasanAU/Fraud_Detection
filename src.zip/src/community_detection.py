"""
05_community_detection.py
==========================
Detect transaction communities using the Louvain algorithm and
engineer community-structural features per node.

Community Features
------------------
- comm_id              : community label (integer, label-encoded)
- comm_size            : number of nodes in the node's community
- comm_intra_edges     : edges within the same community
- comm_inter_edges     : edges crossing community boundaries
- comm_intra_ratio     : intra / (intra + inter)
- comm_density         : edge density within the community subgraph
- comm_illicit_ratio   : fraction of labelled illicit nodes in community
                         (computed on training set only to prevent leakage)
- comm_modularity_gain : per-node modularity contribution (approx.)

Note: Louvain requires undirected graph. We use the undirected
projection of the Elliptic DAG, which is standard practice.
"""

import logging
import os

import community as community_louvain   # python-louvain
import networkx as nx
import numpy as np
import pandas as pd
import yaml
from tqdm import tqdm

log = logging.getLogger("CommunityDetection")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def detect_communities_and_features(config_path: str = "config.yaml") -> pd.DataFrame:
    cfg   = _load_config(config_path)
    paths = cfg["paths"]
    ccfg  = cfg["community"]
    ck    = paths["checkpoints_dir"]

    out_path = f"{ck}/community_features.parquet"

    # ── Load data ──────────────────────────────────────────────────────────────
    log.info("Loading edges and label data…")
    edges    = pd.read_parquet(f"{ck}/edges.parquet")
    df_train = pd.read_parquet(f"{ck}/train_data.parquet")
    df_test  = pd.read_parquet(f"{ck}/test_data.parquet")
    df_all   = pd.concat([df_train, df_test], ignore_index=True)

    # Label lookup (training set only — to compute comm_illicit_ratio without leakage)
    train_label = dict(zip(df_train["txId"], df_train["label"]))

    # ── Build undirected graph ─────────────────────────────────────────────────
    log.info("Building undirected graph for Louvain…")
    G_dir  = nx.from_pandas_edgelist(edges, source="txId1", target="txId2",
                                     create_using=nx.DiGraph())
    G_und  = G_dir.to_undirected()
    log.info(f"Undirected graph: {G_und.number_of_nodes():,} nodes | "
             f"{G_und.number_of_edges():,} edges")

    # ── Louvain community detection ────────────────────────────────────────────
    log.info("Running Louvain community detection…")
    partition = community_louvain.best_partition(
        G_und,
        resolution=ccfg["resolution"],
        random_state=ccfg["seed"]
    )
    modularity = community_louvain.modularity(partition, G_und)
    n_comms    = len(set(partition.values()))
    log.info(f"Communities found: {n_comms:,}  |  Modularity Q = {modularity:.4f}")

    # ── Community statistics ───────────────────────────────────────────────────
    log.info("Computing community-level statistics…")

    # comm_id → list of nodes
    comm_to_nodes: dict = {}
    for node, comm in partition.items():
        comm_to_nodes.setdefault(comm, []).append(node)

    # Community size
    comm_size_map = {c: len(ns) for c, ns in comm_to_nodes.items()}

    # Intra / inter edge counts per community
    comm_intra: dict = {c: 0 for c in comm_to_nodes}
    comm_inter: dict = {c: 0 for c in comm_to_nodes}
    for u, v in G_und.edges():
        cu, cv = partition.get(u), partition.get(v)
        if cu is not None and cv is not None:
            if cu == cv:
                comm_intra[cu] = comm_intra.get(cu, 0) + 1
            else:
                comm_inter[cu] = comm_inter.get(cu, 0) + 1
                comm_inter[cv] = comm_inter.get(cv, 0) + 1

    # Community density (edges / possible edges in subgraph)
    comm_density: dict = {}
    for c, nodes in tqdm(comm_to_nodes.items(), desc="Community density"):
        sub = G_und.subgraph(nodes)
        n   = sub.number_of_nodes()
        e   = sub.number_of_edges()
        possible = n * (n - 1) / 2 if n > 1 else 1
        comm_density[c] = e / possible

    # Illicit ratio per community (from TRAINING set only)
    comm_illicit_ratio: dict = {}
    for c, nodes in comm_to_nodes.items():
        labels_in_comm = [train_label[n] for n in nodes if n in train_label and train_label[n] != -1]
        if labels_in_comm:
            comm_illicit_ratio[c] = sum(labels_in_comm) / len(labels_in_comm)
        else:
            comm_illicit_ratio[c] = 0.0

    # ── Assemble per-node features ─────────────────────────────────────────────
    log.info("Assembling community features per node…")
    records = []
    for _, row in tqdm(df_all.iterrows(), total=len(df_all), desc="Community features"):
        node = row["txId"]
        c    = partition.get(node, -1)
        intra = comm_intra.get(c, 0)
        inter = comm_inter.get(c, 0)
        total = intra + inter
        records.append({
            "txId":                 node,
            "comm_id":              c,
            "comm_size":            comm_size_map.get(c, 0),
            "comm_intra_edges":     intra,
            "comm_inter_edges":     inter,
            "comm_intra_ratio":     intra / total if total > 0 else 0.0,
            "comm_density":         comm_density.get(c, 0.0),
            "comm_illicit_ratio":   comm_illicit_ratio.get(c, 0.0),
            "comm_log_size":        np.log1p(comm_size_map.get(c, 0)),
        })

    comm_df = pd.DataFrame(records)
    log.info(f"Community features shape: {comm_df.shape}")

    # ── Save ───────────────────────────────────────────────────────────────────
    comm_df.to_parquet(out_path, index=False)
    log.info(f"Community features saved → {out_path}")

    return comm_df


if __name__ == "__main__":
    comm_df = detect_communities_and_features()
    log.info("Community detection complete.")
