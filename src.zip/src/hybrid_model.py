"""
hybrid_model.py
===================
Combine all model predictions into the final Hybrid Ensemble Model
and apply threshold optimization for maximum F1 on illicit class.

Hybrid Prediction Formula
--------------------------
  hybrid_proba = w1 × stacked_blend
               + w2 × best_base_model_proba
               + w3 × direct_MLP_proba

Where w1, w2, w3 are configured in config.yaml (hybrid section).

Threshold Optimization
-----------------------
  - Search threshold ∈ [0.1, 0.9] with step 0.01
  - Maximize F1 on illicit class (class=1)
  - Apply optimal threshold to test set predictions

Model Persistence
-----------------
  The full hybrid model package is saved as:
    results/models/HYBRID_FINAL_MODEL.joblib

  Contents:
    - All base models (XGBoost, LightGBM, CatBoost, RF, ET, SVM)
    - Meta MLP state dict + architecture params
    - Meta LogReg model
    - Feature scaler & meta scaler
    - Optimal threshold
    - Feature names
    - Performance metrics
    - Config snapshot

  Load & run later with:
    >>> from src.hybrid_model import HybridPredictor
    >>> predictor = HybridPredictor.load("results/models/HYBRID_FINAL_MODEL.joblib")
    >>> y_pred, y_proba = predictor.predict(X_new)
"""

import logging
import os
import warnings
from dataclasses import dataclass, field
from typing import List, Optional

import joblib
import numpy as np
import pandas as pd
import torch
import yaml
from sklearn.metrics import (classification_report, f1_score,
                             precision_recall_curve, roc_auc_score)

from src.stacking_ensemble import MetaMLP

warnings.filterwarnings("ignore")
log = logging.getLogger("HybridModel")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


# ── HybridPredictor (serializable wrapper) ────────────────────────────────────

class HybridPredictor:
    """
    Serializable wrapper for the complete Hybrid Fraud Detection model.
    Supports predict() on new feature matrices with the same column structure.
    """

    def __init__(
        self,
        base_models: dict,
        meta_mlp_state: dict,
        meta_mlp_dims: list,
        meta_mlp_dropout: float,
        meta_mlp_input_dim: int,
        meta_logreg,
        meta_scaler,
        feature_names: list,
        optimal_threshold: float,
        weights: dict,
        metrics: dict,
        config: dict,
    ):
        self.base_models        = base_models
        self.meta_mlp_state     = meta_mlp_state
        self.meta_mlp_dims      = meta_mlp_dims
        self.meta_mlp_dropout   = meta_mlp_dropout
        self.meta_mlp_input_dim = meta_mlp_input_dim
        self.meta_logreg        = meta_logreg
        self.meta_scaler        = meta_scaler
        self.feature_names      = feature_names
        self.optimal_threshold  = optimal_threshold
        self.weights            = weights
        self.metrics            = metrics
        self.config             = config

    def _rebuild_mlp(self) -> MetaMLP:
        mlp = MetaMLP(
            self.meta_mlp_input_dim,
            self.meta_mlp_dims,
            self.meta_mlp_dropout
        )
        mlp.load_state_dict(self.meta_mlp_state)
        mlp.eval()
        return mlp

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return hybrid probability scores for each sample."""
        # Base model probabilities
        base_probas = np.column_stack([
            m.predict_proba(X)[:, 1]
            for m in self.base_models.values()
        ])

        # Meta-features
        meta_scaled = self.meta_scaler.transform(base_probas)

        # MLP meta prediction
        mlp = self._rebuild_mlp()
        with torch.no_grad():
            mlp_proba = mlp(
                torch.tensor(meta_scaled, dtype=torch.float32)
            ).numpy()

        # LogReg meta prediction
        lr_proba = self.meta_logreg.predict_proba(meta_scaled)[:, 1]

        # Stacked blend
        blend = 0.6 * mlp_proba + 0.4 * lr_proba

        # Best base model (first in dict = xgboost by convention)
        best_base_proba = list(self.base_models.values())[0].predict_proba(X)[:, 1]

        # Final hybrid combination
        w = self.weights
        hybrid = (
            w["stacked_mlp_weight"]  * blend
            + w["best_base_weight"]  * best_base_proba
            + w["direct_mlp_weight"] * mlp_proba
        )
        return hybrid

    def predict(self, X: np.ndarray) -> tuple:
        """Return (y_pred, y_proba) using optimal threshold."""
        proba = self.predict_proba(X)
        pred  = (proba >= self.optimal_threshold).astype(int)
        return pred, proba

    def save(self, path: str):
        joblib.dump(self, path)
        log.info(f"HybridPredictor saved → {path}")

    @staticmethod
    def load(path: str) -> "HybridPredictor":
        predictor = joblib.load(path)
        log.info(f"HybridPredictor loaded from → {path}")
        return predictor


# ── Threshold optimization ─────────────────────────────────────────────────────

def optimize_threshold(y_true: np.ndarray, y_proba: np.ndarray, step: float = 0.01) -> float:
    best_t, best_f1 = 0.5, 0.0
    for t in np.arange(0.1, 0.9, step):
        f1 = f1_score(y_true, (y_proba >= t).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_t = f1, t
    log.info(f"Optimal threshold: {best_t:.2f}  (F1={best_f1:.4f})")
    return float(best_t)


# ── Main assembly ─────────────────────────────────────────────────────────────

def build_hybrid_model(
    base_results: dict,
    stack_results: dict,
    X_test: np.ndarray,
    y_test: np.ndarray,
    feature_names: list,
    config_path: str = "config.yaml"
) -> HybridPredictor:
    """
    Parameters
    ----------
    base_results   : output of train_base_models()
    stack_results  : output of train_stacking_ensemble()
    X_test         : scaled test features
    y_test         : test labels
    feature_names  : list of feature column names
    """
    cfg   = _load_config(config_path)
    paths = cfg["paths"]
    md    = paths["models_dir"]
    ck    = paths["checkpoints_dir"]
    hcfg  = cfg["hybrid"]
    mlpc  = cfg["mlp"]
    seed  = cfg["random_seed"]
    os.makedirs(md, exist_ok=True)

    base_models    = base_results["trained_models"]
    model_names    = base_results["model_names"]
    meta_scaler    = stack_results["meta_scaler"]
    mlp_model      = stack_results["mlp"]
    logreg_model   = stack_results["logreg"]

    # ── Compute base model test probas ─────────────────────────────────────────
    log.info("Computing base model probabilities on test set…")
    base_test_probas = np.column_stack([
        base_models[n].predict_proba(X_test)[:, 1]
        for n in model_names
    ])

    # ── Meta-features (scaled) ─────────────────────────────────────────────────
    meta_scaled = meta_scaler.transform(base_test_probas)

    # ── MLP meta-learner prediction ────────────────────────────────────────────
    mlp_model.eval()
    with torch.no_grad():
        mlp_proba = mlp_model(
            torch.tensor(meta_scaled, dtype=torch.float32)
        ).numpy()

    # ── LogReg meta prediction ─────────────────────────────────────────────────
    lr_proba    = logreg_model.predict_proba(meta_scaled)[:, 1]
    blend_proba = 0.6 * mlp_proba + 0.4 * lr_proba

    # ── Best base model (XGBoost by convention) ────────────────────────────────
    best_base_proba = base_models["xgboost"].predict_proba(X_test)[:, 1]

    # ── Hybrid combination ─────────────────────────────────────────────────────
    w = hcfg
    hybrid_proba = (
        w["stacked_mlp_weight"]  * blend_proba
        + w["best_base_weight"]  * best_base_proba
        + w["direct_mlp_weight"] * mlp_proba
    )

    # ── Threshold optimization ─────────────────────────────────────────────────
    log.info("Optimizing classification threshold…")
    optimal_threshold = optimize_threshold(
        y_test, hybrid_proba, step=hcfg["threshold_search_step"]
    )

    # ── Final evaluation ───────────────────────────────────────────────────────
    y_pred = (hybrid_proba >= optimal_threshold).astype(int)
    f1    = f1_score(y_test, y_pred)
    try:
        auc = roc_auc_score(y_test, hybrid_proba)
    except ValueError:
        auc = 0.5
    report = classification_report(y_test, y_pred, target_names=["Licit", "Illicit"])
    log.info(f"\nHybrid Model Final Results:\n{report}")
    log.info(f"AUC-ROC: {auc:.4f}")

    metrics = {
        "f1":                 f1,
        "auc_roc":            auc,
        "optimal_threshold":  optimal_threshold,
        "classification_report": report,
    }

    # ── Save predictions ───────────────────────────────────────────────────────
    pd.DataFrame({
        "hybrid_proba": hybrid_proba,
        "y_pred":       y_pred,
        "y_true":       y_test,
    }).to_parquet(f"{ck}/hybrid_predictions.parquet", index=False)

    # ── Build & save HybridPredictor ───────────────────────────────────────────
    predictor = HybridPredictor(
        base_models        = base_models,
        meta_mlp_state     = mlp_model.state_dict(),
        meta_mlp_dims      = mlpc["hidden_dims"],
        meta_mlp_dropout   = mlpc["dropout"],
        meta_mlp_input_dim = base_test_probas.shape[1],
        meta_logreg        = logreg_model,
        meta_scaler        = meta_scaler,
        feature_names      = feature_names,
        optimal_threshold  = optimal_threshold,
        weights            = hcfg,
        metrics            = metrics,
        config             = cfg,
    )

    model_path = f"{md}/HYBRID_FINAL_MODEL.joblib"
    predictor.save(model_path)
    log.info(f"✅ HYBRID FINAL MODEL saved → {model_path}")
    log.info("   To reload: HybridPredictor.load('results/models/HYBRID_FINAL_MODEL.joblib')")

    return predictor


if __name__ == "__main__":
    log.info("Hybrid model module loaded.")
    log.info("Usage: build_hybrid_model(base_results, stack_results, X_test, y_test, feature_names)")
