"""
06_feature_fusion.py
=====================
Merge all 5 feature streams into a unified feature matrix and
apply advanced feature selection:

Streams
-------
  Stream 1 — Raw transaction features (after variance/correlation filter)
  Stream 2 — SNA graph features (11 features)
  Stream 3 — Node2Vec embeddings (64 features)
  Stream 4 — Temporal features (10 features)
  Stream 5 — Community detection features (9 features)

Feature Selection Pipeline
---------------------------
1. Fill missing values (nodes with no graph connections → zeros)
2. Remove near-zero variance features
3. Remove highly correlated features (Pearson > 0.95)
4. StandardScaler normalization
5. PCA on raw features (retain 95% variance)
6. RFECV on full fused matrix (using ExtraTreesClassifier, fast)
7. Final feature set saved for downstream models
"""

import logging
import os
import warnings

import numpy as np
import pandas as pd
import yaml
from sklearn.decomposition import PCA
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import RFECV, SelectFromModel, VarianceThreshold
from sklearn.preprocessing import StandardScaler
from tqdm import tqdm

warnings.filterwarnings("ignore")
log = logging.getLogger("FeatureFusion")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def _remove_high_correlation(X: pd.DataFrame, threshold: float) -> pd.DataFrame:
    corr = X.corr(method="pearson").abs()
    upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
    to_drop = [c for c in upper.columns if any(upper[c] > threshold)]
    log.info(f"  Correlation filter: dropping {len(to_drop)} features (>{threshold:.2f})")
    return X.drop(columns=to_drop)


def fuse_features(config_path: str = "config.yaml") -> tuple:
    """
    Returns
    -------
    X_train : pd.DataFrame  — fused & selected features for training
    X_test  : pd.DataFrame  — same columns, test set
    y_train : pd.Series
    y_test  : pd.Series
    feature_names : list
    """
    cfg  = _load_config(config_path)
    paths = cfg["paths"]
    fs    = cfg["feature_selection"]
    ck    = paths["checkpoints_dir"]
    seed  = cfg["random_seed"]

    out_train = f"{ck}/X_train_fused.parquet"
    out_test  = f"{ck}/X_test_fused.parquet"

    # ── Load all streams ───────────────────────────────────────────────────────
    log.info("Loading feature streams…")
    df_train = pd.read_parquet(f"{ck}/train_data.parquet")
    df_test  = pd.read_parquet(f"{ck}/test_data.parquet")
    sna_df   = pd.read_parquet(f"{ck}/sna_features.parquet")
    n2v_df   = pd.read_parquet(f"{ck}/node2vec_embeddings.parquet")
    temp_df  = pd.read_parquet(f"{ck}/temporal_features.parquet")
    comm_df  = pd.read_parquet(f"{ck}/community_features.parquet")

    raw_feat_cols = [c for c in df_train.columns
                     if c not in ("txId", "time_step", "label")]
    log.info(f"Raw features after initial selection: {len(raw_feat_cols)}")

    def _merge_stream(base_df, extra_df, stream_name):
        merged = base_df.merge(extra_df, on="txId", how="left")
        new_cols = [c for c in extra_df.columns if c != "txId"]
        merged[new_cols] = merged[new_cols].fillna(0.0)
        log.info(f"  Merged {stream_name}: +{len(new_cols)} features")
        return merged

    log.info("Merging streams into train set…")
    df_tr = df_train.copy()
    df_tr = _merge_stream(df_tr, sna_df,   "SNA (graph)")
    df_tr = _merge_stream(df_tr, n2v_df,   "Node2Vec")
    df_tr = _merge_stream(df_tr, temp_df,  "Temporal")
    df_tr = _merge_stream(df_tr, comm_df,  "Community")

    log.info("Merging streams into test set…")
    df_te = df_test.copy()
    df_te = _merge_stream(df_te, sna_df,   "SNA (graph)")
    df_te = _merge_stream(df_te, n2v_df,   "Node2Vec")
    df_te = _merge_stream(df_te, temp_df,  "Temporal")
    df_te = _merge_stream(df_te, comm_df,  "Community")

    # ── Drop Unknown Nodes Before Supervised Sub-Pipelines ─────────────────────
    train_known = df_tr["label"] != -1
    test_known  = df_te["label"] != -1
    
    df_tr = df_tr[train_known].reset_index(drop=True)
    df_te = df_te[test_known].reset_index(drop=True)

    y_train = df_tr["label"]
    y_test  = df_te["label"]

    all_feat_cols = [c for c in df_tr.columns
                     if c not in ("txId", "time_step", "label", "class")]

    X_tr = df_tr[all_feat_cols].copy()
    X_te = df_te[all_feat_cols].copy()
    log.info(f"Total features before selection: {X_tr.shape[1]}")
    log.info(f"Filtered out unknowns. Training nodes: {len(X_tr):,}, Testing nodes: {len(X_te):,}")

    # ── Feature Selection Step 1: Variance threshold ───────────────────────────
    log.info("Step 1: Variance threshold filter…")
    vt = VarianceThreshold(threshold=fs["variance_threshold"])
    X_tr_arr = vt.fit_transform(X_tr)
    X_te_arr = vt.transform(X_te)
    kept_mask = vt.get_support()
    feat_after_vt = [f for f, k in zip(all_feat_cols, kept_mask) if k]
    X_tr = pd.DataFrame(X_tr_arr, columns=feat_after_vt)
    X_te = pd.DataFrame(X_te_arr, columns=feat_after_vt)
    log.info(f"  After variance filter: {X_tr.shape[1]} features")

    # ── Feature Selection Step 2: Correlation filter ───────────────────────────
    log.info("Step 2: Correlation filter…")
    X_tr = _remove_high_correlation(X_tr, threshold=fs["correlation_threshold"])
    X_te = X_te[X_tr.columns]
    log.info(f"  After correlation filter: {X_tr.shape[1]} features")

    # ── Feature Selection Step 3: PCA on raw features only ────────────────────
    log.info(f"Step 3: PCA on raw features (target variance={fs['pca_variance_threshold']})…")
    raw_cols_tr = [c for c in X_tr.columns
                   if c.startswith("lf_") or c.startswith("af_") or c.startswith("extra_")]
    non_raw_cols = [c for c in X_tr.columns if c not in raw_cols_tr]

    if raw_cols_tr:
        scaler_raw = StandardScaler()
        X_raw_tr = scaler_raw.fit_transform(X_tr[raw_cols_tr])
        X_raw_te = scaler_raw.transform(X_te[raw_cols_tr])

        pca = PCA(n_components=fs["pca_variance_threshold"], svd_solver="full", random_state=seed)
        X_pca_tr = pca.fit_transform(X_raw_tr)
        X_pca_te = pca.transform(X_raw_te)
        n_comp   = pca.n_components_
        log.info(f"  PCA retained {n_comp} components from {len(raw_cols_tr)} raw features")

        pca_cols = [f"pca_{i}" for i in range(n_comp)]
        X_tr = pd.concat([
            pd.DataFrame(X_pca_tr, columns=pca_cols, index=X_tr.index),
            X_tr[non_raw_cols].reset_index(drop=True)
        ], axis=1)
        X_te = pd.concat([
            pd.DataFrame(X_pca_te, columns=pca_cols, index=X_te.index),
            X_te[non_raw_cols].reset_index(drop=True)
        ], axis=1)

    log.info(f"  After PCA: {X_tr.shape[1]} features")

    # ── Feature Selection Step 4: RFECV (ExtraTreesClassifier — fast) ─────────
    log.info("Step 4: RFECV feature selection (this may take a few minutes)…")
    etc = ExtraTreesClassifier(
        n_estimators=100,
        n_jobs=-1,
        random_state=seed,
        class_weight="balanced"
    )

    # Standardize for RFECV
    scaler_all = StandardScaler()
    X_tr_scaled = scaler_all.fit_transform(X_tr)
    X_te_scaled = scaler_all.transform(X_te)

    rfecv = RFECV(
        estimator=etc,
        step=1,
        cv=fs["rfecv_cv_folds"],
        scoring=fs["rfecv_scoring"],
        n_jobs=-1,
        min_features_to_select=20,
    )
    rfecv.fit(X_tr_scaled, y_train)
    selected_mask  = rfecv.support_
    selected_feats = [f for f, s in zip(X_tr.columns.tolist(), selected_mask) if s]
    log.info(f"  RFECV selected {len(selected_feats)} features "
             f"(optimal CV score: {rfecv.cv_results_['mean_test_score'].max():.4f})")

    X_tr_final = pd.DataFrame(
        rfecv.transform(X_tr_scaled),
        columns=selected_feats
    )
    X_te_final = pd.DataFrame(
        rfecv.transform(X_te_scaled),
        columns=selected_feats
    )

    log.info(f"Final feature matrix: train={X_tr_final.shape}, test={X_te_final.shape}")

    # ── Save ───────────────────────────────────────────────────────────────────
    X_tr_final["txId"]  = df_tr["txId"].values
    X_tr_final["label"] = y_train.values
    X_te_final["txId"]  = df_te["txId"].values
    X_te_final["label"] = y_test.values

    X_tr_final.to_parquet(out_train, index=False)
    X_te_final.to_parquet(out_test,  index=False)
    pd.Series(selected_feats).to_csv(
        f"{ck}/selected_feature_names.csv", index=False, header=["feature"]
    )
    log.info(f"Fused feature matrices saved → {ck}/")

    return X_tr_final.drop(columns=["txId", "label"]), \
           X_te_final.drop(columns=["txId", "label"]), \
           y_train, y_test, selected_feats


if __name__ == "__main__":
    X_tr, X_te, y_tr, y_te, feats = fuse_features()
    log.info(f"Feature fusion complete. Shape: {X_tr.shape}")
