"""
04_temporal_features.py
========================
Engineer temporal features from the time-step dimension of the Elliptic dataset.

Each Bitcoin transaction belongs to a time-step (1–49) representing a 2-week
snapshot. These features capture the temporal activity patterns of nodes
that appear across multiple time-steps in the edge structure.

Temporal Features
-----------------
- time_step          : the transaction's own time-step (already in raw data)
- ts_first / ts_last : first & last time-step a node's neighbors appear
- ts_duration        : ts_last - ts_first (activity lifespan)
- ts_unique_steps    : number of unique time-steps a node is involved in
- ts_neighbor_mean_ts: mean time-step of direct neighbors
- ts_neighbor_std_ts : std of neighbor time-steps (dispersion)
- ts_in_velocity     : rate of in-degree growth across time
- ts_out_velocity    : rate of out-degree growth across time
- ts_burst_flag      : 1 if node has high out-degree in a single time-step
- ts_relative_pos    : normalized position in timeline (time_step / 49)
"""

import logging
import os

import numpy as np
import pandas as pd
import networkx as nx
import yaml
from tqdm import tqdm

log = logging.getLogger("TemporalFeatures")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def build_temporal_features(config_path: str = "config.yaml") -> pd.DataFrame:
    cfg   = _load_config(config_path)
    paths = cfg["paths"]
    ck    = paths["checkpoints_dir"]

    out_path = f"{ck}/temporal_features.parquet"

    # ── Load data ──────────────────────────────────────────────────────────────
    log.info("Loading train & test checkpoints…")
    df_train = pd.read_parquet(f"{ck}/train_data.parquet")
    df_test  = pd.read_parquet(f"{ck}/test_data.parquet")
    df_all   = pd.concat([df_train, df_test], ignore_index=True)

    edges = pd.read_parquet(f"{ck}/edges.parquet")

    # Build a txId → time_step lookup (for all labelled nodes)
    ts_lookup = dict(zip(df_all["txId"], df_all["time_step"]))
    max_ts = df_all["time_step"].max()

    log.info(f"Total labelled nodes: {len(ts_lookup):,}  |  max time-step: {max_ts}")

    # ── Build directed graph ───────────────────────────────────────────────────
    log.info("Building directed graph for temporal analysis…")
    G = nx.from_pandas_edgelist(
        edges, source="txId1", target="txId2",
        create_using=nx.DiGraph()
    )

    # ── Compute per-node temporal features ────────────────────────────────────
    log.info("Computing temporal features per node…")
    records = []

    for node in tqdm(df_all["txId"], desc="Temporal features"):
        own_ts = ts_lookup.get(node, np.nan)

        # Predecessor (in-neighbor) time-steps
        preds    = list(G.predecessors(node)) if G.has_node(node) else []
        pred_ts  = [ts_lookup[p] for p in preds if p in ts_lookup]

        # Successor (out-neighbor) time-steps
        succs    = list(G.successors(node)) if G.has_node(node) else []
        succ_ts  = [ts_lookup[s] for s in succs if s in ts_lookup]

        all_neighbor_ts = pred_ts + succ_ts
        all_ts          = [own_ts] + all_neighbor_ts if not np.isnan(own_ts) else all_neighbor_ts

        ts_first    = min(all_ts) if all_ts else own_ts
        ts_last     = max(all_ts) if all_ts else own_ts
        ts_duration = (ts_last - ts_first) if (all_ts and not np.isnan(ts_first)) else 0
        ts_unique   = len(set(all_ts)) if all_ts else 1
        nb_mean_ts  = float(np.mean(all_neighbor_ts)) if all_neighbor_ts else own_ts
        nb_std_ts   = float(np.std(all_neighbor_ts))  if len(all_neighbor_ts) > 1 else 0.0

        # Velocity: degree change per unit time (normalized by activity duration)
        ts_in_vel  = len(pred_ts) / max(ts_duration, 1)
        ts_out_vel = len(succ_ts) / max(ts_duration, 1)

        # Burst flag: high out-degree relative to mean
        ts_burst = 1 if len(succs) > 5 else 0  # simple heuristic

        ts_rel_pos = own_ts / max_ts if not np.isnan(own_ts) else 0.5

        records.append({
            "txId":             node,
            "ts_first":         ts_first if not np.isnan(ts_first) else own_ts,
            "ts_last":          ts_last  if not np.isnan(ts_last)  else own_ts,
            "ts_duration":      ts_duration,
            "ts_unique_steps":  ts_unique,
            "ts_neighbor_mean": nb_mean_ts if not np.isnan(nb_mean_ts) else own_ts,
            "ts_neighbor_std":  nb_std_ts,
            "ts_in_velocity":   ts_in_vel,
            "ts_out_velocity":  ts_out_vel,
            "ts_burst_flag":    ts_burst,
            "ts_relative_pos":  ts_rel_pos,
        })

    temp_df = pd.DataFrame(records)
    log.info(f"Temporal features shape: {temp_df.shape}")

    # ── Save ───────────────────────────────────────────────────────────────────
    temp_df.to_parquet(out_path, index=False)
    log.info(f"Temporal features saved → {out_path}")

    return temp_df


if __name__ == "__main__":
    temp_df = build_temporal_features()
    log.info("Temporal features complete.")
