"""
03_node2vec_embeddings.py
==========================
Generate Node2Vec graph embeddings for every transaction node.

Configuration (from config.yaml)
- dimensions:  64
- walk_length: 20  (reduced for CPU speed)
- num_walks:   50  (reduced for CPU speed)
- p: 1.0,  q: 0.5  (DFS-biased — better community structure capture)

Temporal leakage prevention
- Embeddings are trained on the FULL graph structure (edges are
  structural, not temporal in the same sense as labels).
- Labels are never used during embedding training.
- Train/test split is applied AFTER embedding by matching txIds.

Checkpointing
- Embeddings saved to: results/checkpoints/node2vec_embeddings.parquet
- Re-run is skipped automatically if checkpoint exists.
"""

import logging
import os
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from gensim.models import Word2Vec
from node2vec import Node2Vec
import networkx as nx

log = logging.getLogger("Node2Vec")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def generate_node2vec_embeddings(config_path: str = "config.yaml") -> pd.DataFrame:
    cfg  = _load_config(config_path)
    paths = cfg["paths"]
    n2v   = cfg["node2vec"]
    ck    = paths["checkpoints_dir"]

    out_path = f"{ck}/node2vec_embeddings.parquet"

    # ── Checkpointing ──────────────────────────────────────────────────────────
    if os.path.exists(out_path):
        log.info(f"Node2Vec checkpoint found — skipping training. Loading {out_path}")
        return pd.read_parquet(out_path)

    # ── Load edges ─────────────────────────────────────────────────────────────
    log.info("Loading edges…")
    edges = pd.read_parquet(f"{ck}/edges.parquet")

    # ── Build graph (undirected for Node2Vec walks) ────────────────────────────
    log.info("Building undirected graph for Node2Vec…")
    G = nx.from_pandas_edgelist(
        edges, source="txId1", target="txId2",
        create_using=nx.Graph()     # undirected
    )
    log.info(f"Graph: {G.number_of_nodes():,} nodes | {G.number_of_edges():,} edges")

    # ── Node2Vec walks ─────────────────────────────────────────────────────────
    log.info(f"Generating Node2Vec walks: {n2v['num_walks']} walks × "
             f"length {n2v['walk_length']}, dim={n2v['dimensions']}…")
    log.warning("This will take ~1–2 hours on CPU. Grab a coffee ☕")

    node2vec_model = Node2Vec(
        graph=G,
        dimensions=n2v["dimensions"],
        walk_length=n2v["walk_length"],
        num_walks=n2v["num_walks"],
        p=n2v["p"],
        q=n2v["q"],
        workers=n2v["workers"],
        seed=n2v["seed"],
        quiet=False,
    )

    log.info("Training Word2Vec on walks…")
    w2v = node2vec_model.fit(
        window=n2v["window"],
        min_count=n2v["min_count"],
        batch_words=128,
    )

    # ── Extract embeddings ─────────────────────────────────────────────────────
    log.info("Extracting per-node embeddings…")
    dim = n2v["dimensions"]
    embed_cols = [f"n2v_{i}" for i in range(dim)]

    records = []
    for node in G.nodes():
        node_str = str(node)
        if node_str in w2v.wv:
            vec = w2v.wv[node_str]
        else:
            vec = np.zeros(dim)
        records.append([node] + vec.tolist())

    emb_df = pd.DataFrame(records, columns=["txId"] + embed_cols)
    emb_df["txId"] = emb_df["txId"].astype(np.int64)
    log.info(f"Embeddings shape: {emb_df.shape}")

    # ── Save ───────────────────────────────────────────────────────────────────
    emb_df.to_parquet(out_path, index=False)
    log.info(f"Node2Vec embeddings saved → {out_path}")

    return emb_df


if __name__ == "__main__":
    emb = generate_node2vec_embeddings()
    log.info("Node2Vec complete.")
