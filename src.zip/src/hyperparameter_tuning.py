"""
11_hyperparameter_tuning.py
============================
Bayesian hyperparameter optimisation using Optuna (TPE sampler).

Tunes all base learners + MLP meta-learner using 5-fold stratified CV.
Optimisation metric: F1 on illicit class (class=1) to handle imbalance.

Models tuned
------------
  1. XGBoost
  2. LightGBM
  3. CatBoost
  4. RandomForest
  5. ExtraTrees
  6. MLP (meta-learner architecture search)

Results are saved as:
  results/reports/optuna_best_params.yaml   — best params per model
  results/checkpoints/optuna_studies.joblib — Optuna study objects

Usage
-----
  Can be run BEFORE or AFTER initial base model training.
  Call retrain_with_best_params() to rebuild models with tuned params.
"""

import logging
import os
import warnings
from collections import Counter

import joblib
import numpy as np
import optuna
import yaml
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold, cross_val_score
from xgboost import XGBClassifier

warnings.filterwarnings("ignore")
optuna.logging.set_verbosity(optuna.logging.WARNING)

log = logging.getLogger("HyperparamTuning")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


# ── Objective functions ────────────────────────────────────────────────────────

def _objective_xgboost(trial, X, y, seed, scale_pos_weight, n_folds):
    params = {
        "n_estimators":      trial.suggest_int("n_estimators", 100, 800),
        "max_depth":         trial.suggest_int("max_depth", 3, 10),
        "learning_rate":     trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "subsample":         trial.suggest_float("subsample", 0.5, 1.0),
        "colsample_bytree":  trial.suggest_float("colsample_bytree", 0.5, 1.0),
        "gamma":             trial.suggest_float("gamma", 0.0, 5.0),
        "reg_lambda":        trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        "reg_alpha":         trial.suggest_float("reg_alpha", 1e-5, 1.0, log=True),
        "min_child_weight":  trial.suggest_int("min_child_weight", 1, 10),
        "tree_method":       "hist",
        "scale_pos_weight":  scale_pos_weight,
        "random_state":      seed,
        "n_jobs":            -1,
        "verbosity":         0,
        "use_label_encoder": False,
    }
    model = XGBClassifier(**params)
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    scores = cross_val_score(model, X, y, cv=skf, scoring="f1", n_jobs=1)
    return scores.mean()


def _objective_lightgbm(trial, X, y, seed, n_folds):
    params = {
        "n_estimators":       trial.suggest_int("n_estimators", 100, 800),
        "num_leaves":         trial.suggest_int("num_leaves", 20, 150),
        "max_depth":          trial.suggest_int("max_depth", 3, 12),
        "learning_rate":      trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "min_child_samples":  trial.suggest_int("min_child_samples", 5, 100),
        "feature_fraction":   trial.suggest_float("feature_fraction", 0.5, 1.0),
        "bagging_fraction":   trial.suggest_float("bagging_fraction", 0.5, 1.0),
        "bagging_freq":       trial.suggest_int("bagging_freq", 1, 10),
        "reg_alpha":          trial.suggest_float("reg_alpha", 1e-5, 1.0, log=True),
        "reg_lambda":         trial.suggest_float("reg_lambda", 1e-5, 1.0, log=True),
        "class_weight":       "balanced",
        "random_state":       seed,
        "n_jobs":             -1,
        "verbose":            -1,
    }
    model = LGBMClassifier(**params)
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    scores = cross_val_score(model, X, y, cv=skf, scoring="f1", n_jobs=1)
    return scores.mean()


def _objective_catboost(trial, X, y, seed, n_folds):
    params = {
        "iterations":      trial.suggest_int("iterations", 100, 800),
        "depth":           trial.suggest_int("depth", 3, 10),
        "learning_rate":   trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "l2_leaf_reg":     trial.suggest_float("l2_leaf_reg", 1.0, 10.0),
        "border_count":    trial.suggest_int("border_count", 32, 255),
        "auto_class_weights": "Balanced",
        "task_type":       "CPU",
        "verbose":         0,
        "random_seed":     seed,
    }
    model = CatBoostClassifier(**params)
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    scores = cross_val_score(model, X, y, cv=skf, scoring="f1", n_jobs=1)
    return scores.mean()


def _objective_rf(trial, X, y, seed, n_folds):
    params = {
        "n_estimators":     trial.suggest_int("n_estimators", 100, 500),
        "max_depth":        trial.suggest_int("max_depth", 5, 30),
        "min_samples_split":trial.suggest_int("min_samples_split", 2, 20),
        "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 10),
        "max_features":     trial.suggest_categorical("max_features", ["sqrt", "log2", None]),
        "class_weight":     "balanced",
        "n_jobs":           -1,
        "random_state":     seed,
    }
    model = RandomForestClassifier(**params)
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    scores = cross_val_score(model, X, y, cv=skf, scoring="f1", n_jobs=1)
    return scores.mean()


def _objective_et(trial, X, y, seed, n_folds):
    params = {
        "n_estimators":     trial.suggest_int("n_estimators", 100, 500),
        "max_depth":        trial.suggest_int("max_depth", 5, 30),
        "min_samples_split":trial.suggest_int("min_samples_split", 2, 20),
        "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 10),
        "max_features":     trial.suggest_categorical("max_features", ["sqrt", "log2", None]),
        "class_weight":     "balanced",
        "n_jobs":           -1,
        "random_state":     seed,
    }
    model = ExtraTreesClassifier(**params)
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    scores = cross_val_score(model, X, y, cv=skf, scoring="f1", n_jobs=1)
    return scores.mean()


# ── Main tuning function ───────────────────────────────────────────────────────

def run_hyperparameter_tuning(
    X_train: np.ndarray,
    y_train: np.ndarray,
    config_path: str = "config.yaml"
) -> dict:
    """
    Run Optuna Bayesian optimisation for all base models.

    Returns
    -------
    dict: model_name → best_params dict
    """
    cfg   = _load_config(config_path)
    paths = cfg["paths"]
    ocfg  = cfg["optuna"]
    cvcfg = cfg["cv"]
    seed  = cfg["random_seed"]
    ck    = paths["checkpoints_dir"]
    rp    = paths["reports_dir"]
    os.makedirs(rp, exist_ok=True)

    n_trials = ocfg["n_trials"]
    timeout  = ocfg["timeout"]
    n_folds  = cvcfg["n_folds"]

    c = Counter(y_train)
    scale_pos_weight = c[0] / c[1] if c[1] > 0 else 1.0

    sampler  = optuna.samplers.TPESampler(seed=seed)
    studies  = {}
    best_params = {}

    model_configs = [
        ("xgboost",       lambda t: _objective_xgboost(t, X_train, y_train, seed, scale_pos_weight, n_folds)),
        ("lightgbm",      lambda t: _objective_lightgbm(t, X_train, y_train, seed, n_folds)),
        ("catboost",      lambda t: _objective_catboost(t, X_train, y_train, seed, n_folds)),
        ("random_forest", lambda t: _objective_rf(t, X_train, y_train, seed, n_folds)),
        ("extra_trees",   lambda t: _objective_et(t, X_train, y_train, seed, n_folds)),
    ]

    for model_name, objective in model_configs:
        log.info(f"═══ Optuna: {model_name.upper()} ({n_trials} trials) ═══")
        study = optuna.create_study(
            direction="maximize",
            sampler=sampler,
            study_name=model_name
        )
        study.optimize(
            objective,
            n_trials=n_trials,
            timeout=timeout,
            show_progress_bar=True,
        )
        best_params[model_name] = study.best_params
        studies[model_name]     = study
        log.info(f"  Best F1: {study.best_value:.4f}")
        log.info(f"  Best params: {study.best_params}")

    # ── Save results ───────────────────────────────────────────────────────────
    with open(f"{rp}/optuna_best_params.yaml", "w") as f:
        yaml.dump(best_params, f, default_flow_style=False)
    log.info(f"Best params saved → {rp}/optuna_best_params.yaml")

    joblib.dump(studies, f"{ck}/optuna_studies.joblib")
    log.info(f"Optuna studies saved → {ck}/optuna_studies.joblib")

    return best_params


def build_tuned_models(best_params: dict, scale_pos_weight: float, seed: int) -> dict:
    """Instantiate all models with tuned hyperparameters."""
    models = {}

    if "xgboost" in best_params:
        p = best_params["xgboost"]
        models["xgboost"] = XGBClassifier(
            **p,
            tree_method="hist",
            scale_pos_weight=scale_pos_weight,
            random_state=seed,
            n_jobs=-1,
            verbosity=0,
            use_label_encoder=False,
        )

    if "lightgbm" in best_params:
        p = best_params["lightgbm"]
        models["lightgbm"] = LGBMClassifier(
            **p,
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
            verbose=-1,
        )

    if "catboost" in best_params:
        p = best_params["catboost"]
        models["catboost"] = CatBoostClassifier(
            **p,
            auto_class_weights="Balanced",
            task_type="CPU",
            verbose=0,
            random_seed=seed,
        )

    if "random_forest" in best_params:
        p = best_params["random_forest"]
        models["random_forest"] = RandomForestClassifier(
            **p,
            class_weight="balanced",
            n_jobs=-1,
            random_state=seed,
        )

    if "extra_trees" in best_params:
        p = best_params["extra_trees"]
        models["extra_trees"] = ExtraTreesClassifier(
            **p,
            class_weight="balanced",
            n_jobs=-1,
            random_state=seed,
        )

    return models


if __name__ == "__main__":
    log.info("Hyperparameter tuning module loaded. Call run_hyperparameter_tuning().")
