"""
12_evaluation.py
=================
Comprehensive model evaluation and publication-quality visualisation.

Metrics Computed
----------------
  Per model: Accuracy, Precision (illicit), Recall (illicit),
             F1 (illicit), F1-macro, F1-weighted, AUC-ROC, AUC-PR, MCC

Plots Generated (300 DPI, PDF + PNG)
-------------------------------------
  01_roc_curves.pdf          — ROC curves for all models
  02_pr_curves.pdf           — Precision-Recall curves
  03_confusion_matrices.pdf  — Confusion matrices (normalized)
  04_f1_comparison.pdf       — Bar chart: illicit F1 per model
  05_shap_beeswarm.pdf       — SHAP beeswarm (top-20 features)
  06_shap_waterfall.pdf      — SHAP waterfall for sample predictions
  07_shap_importance.pdf     — SHAP mean |value| bar chart
  08_learning_curves.pdf     — Optuna optimisation history (if available)
  09_feature_streams.pdf     — Feature importance by stream
  10_hybrid_threshold.pdf    — F1 vs. threshold curve

  11_correlation_heatmap.pdf — Correlation matrix of the top features

Report Saved
------------
  results/reports/evaluation_summary.txt  — console-style metrics table
  results/reports/metrics_all_models.csv  — CSV table for paper tables
  results/reports/metrics_table.tex       — LaTeX table for direct journal insertion
"""

import io
import logging
import os
import warnings
from contextlib import redirect_stdout
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pandas as pd
import seaborn as sns
import shap
import torch
import yaml
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score,
                             matthews_corrcoef, precision_recall_curve,
                             precision_score, recall_score,
                             roc_auc_score, roc_curve, average_precision_score)
from sklearn.preprocessing import label_binarize

warnings.filterwarnings("ignore")
log = logging.getLogger("Evaluation")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)

# ── Styling ───────────────────────────────────────────────────────────────────
PALETTE  = ["#2196F3", "#FF5722", "#4CAF50", "#9C27B0", "#FF9800", "#00BCD4", "#E91E63"]
DPI      = 300
FMT_PDF  = "pdf"
FMT_PNG  = "png"
plt.rcParams.update({
    "font.family":        "DejaVu Sans",
    "font.size":          11,
    "axes.titlesize":     13,
    "axes.labelsize":     12,
    "legend.fontsize":    10,
    "figure.dpi":         DPI,
    "axes.spines.top":    False,
    "axes.spines.right":  False,
})


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def _save_fig(fig, fig_dir: str, name: str):
    os.makedirs(fig_dir, exist_ok=True)
    for fmt in [FMT_PDF, FMT_PNG]:
        path = os.path.join(fig_dir, f"{name}.{fmt}")
        fig.savefig(path, dpi=DPI, bbox_inches="tight")
    log.info(f"  Saved → {fig_dir}/{name}.{{pdf,png}}")
    plt.close(fig)


def safe_roc_auc_score(y_true, y_proba):
    try:
        return roc_auc_score(y_true, y_proba)
    except ValueError:
        return 0.5

def compute_metrics(y_true: np.ndarray, y_proba: np.ndarray,
                    threshold: float = 0.5, name: str = "model") -> dict:
    y_pred = (y_proba >= threshold).astype(int)
    return {
        "model":       name,
        "accuracy":    accuracy_score(y_true, y_pred),
        "precision":   precision_score(y_true, y_pred, zero_division=0),
        "recall":      recall_score(y_true, y_pred, zero_division=0),
        "f1_illicit":  f1_score(y_true, y_pred, zero_division=0),
        "f1_macro":    f1_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "auc_roc":     safe_roc_auc_score(y_true, y_proba),
        "auc_pr":      average_precision_score(y_true, y_proba),
        "mcc":         matthews_corrcoef(y_true, y_pred),
        "threshold":   threshold,
    }


# ── Individual plot functions ──────────────────────────────────────────────────

def plot_roc_curves(all_results: dict, y_true: np.ndarray, fig_dir: str):
    fig, ax = plt.subplots(figsize=(8, 7))
    for i, (name, proba) in enumerate(all_results.items()):
        fpr, tpr, _ = roc_curve(y_true, proba)
        auc = safe_roc_auc_score(y_true, proba)
        ax.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})",
                color=PALETTE[i % len(PALETTE)], lw=2)
    ax.plot([0,1],[0,1], "k--", lw=1, alpha=0.5)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curves — All Models")
    ax.legend(loc="lower right")
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    _save_fig(fig, fig_dir, "01_roc_curves")


def plot_pr_curves(all_results: dict, y_true: np.ndarray, fig_dir: str):
    fig, ax = plt.subplots(figsize=(8, 7))
    for i, (name, proba) in enumerate(all_results.items()):
        prec, rec, _ = precision_recall_curve(y_true, proba)
        auc_pr = average_precision_score(y_true, proba)
        ax.plot(rec, prec, label=f"{name} (AP={auc_pr:.3f})",
                color=PALETTE[i % len(PALETTE)], lw=2)
    baseline = y_true.mean()
    ax.axhline(baseline, linestyle="--", color="gray", alpha=0.6,
               label=f"Baseline ({baseline:.3f})")
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title("Precision-Recall Curves — All Models")
    ax.legend(loc="upper right")
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    _save_fig(fig, fig_dir, "02_pr_curves")


def plot_confusion_matrices(all_results: dict, y_true: np.ndarray,
                            thresholds: dict, fig_dir: str):
    n = len(all_results)
    cols = min(n, 3)
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 5 * rows))
    axes = np.array(axes).flatten()
    for i, (name, proba) in enumerate(all_results.items()):
        t    = thresholds.get(name, 0.5)
        pred = (proba >= t).astype(int)
        cm   = confusion_matrix(y_true, pred, normalize="true")
        sns.heatmap(cm, annot=True, fmt=".2f", cmap="Blues", ax=axes[i],
                    xticklabels=["Licit","Illicit"], yticklabels=["Licit","Illicit"])
        axes[i].set_title(f"{name}\n(t={t:.2f})")
        axes[i].set_ylabel("True"); axes[i].set_xlabel("Predicted")
    for j in range(i+1, len(axes)):
        axes[j].set_visible(False)
    fig.suptitle("Normalised Confusion Matrices", fontsize=14, y=1.01)
    plt.tight_layout()
    _save_fig(fig, fig_dir, "03_confusion_matrices")


def plot_f1_comparison(metrics_list: list, fig_dir: str):
    df = pd.DataFrame(metrics_list)
    df_sorted = df.sort_values("f1_illicit", ascending=True)
    fig, ax = plt.subplots(figsize=(9, 6))
    bars = ax.barh(df_sorted["model"], df_sorted["f1_illicit"],
                   color=PALETTE[:len(df_sorted)])
    for bar, val in zip(bars, df_sorted["f1_illicit"]):
        ax.text(bar.get_width() + 0.005, bar.get_y() + bar.get_height()/2,
                f"{val:.4f}", va="center", fontsize=9)
    ax.set_xlabel("F1 Score (Illicit Class)")
    ax.set_title("F1 Score Comparison — All Models (Illicit Class)")
    ax.set_xlim(0, 1.05)
    ax.axvline(0.86, color="red", linestyle="--", alpha=0.5,
               label="Target (0.86)")
    ax.legend()
    _save_fig(fig, fig_dir, "04_f1_comparison")


def plot_shap_analysis(model, X_test: np.ndarray,
                       feature_names: list, fig_dir: str,
                       max_display: int = 20):
    """SHAP analysis on XGBoost (fastest for large feature sets)."""
    log.info("Computing SHAP values (TreeExplainer on XGBoost)…")
    try:
        explainer   = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test[:500])   # sample for speed

        # Beeswarm
        fig1, ax1 = plt.subplots(figsize=(10, 8))
        shap.summary_plot(
            shap_values, X_test[:500],
            feature_names=feature_names,
            max_display=max_display,
            show=False
        )
        plt.title(f"SHAP Beeswarm Plot (Top-{max_display} Features)")
        plt.tight_layout()
        _save_fig(plt.gcf(), fig_dir, "05_shap_beeswarm")

        # Bar importance
        fig2, ax2 = plt.subplots(figsize=(10, 8))
        shap.summary_plot(
            shap_values, X_test[:500],
            feature_names=feature_names,
            max_display=max_display,
            plot_type="bar",
            show=False
        )
        plt.title(f"SHAP Mean |Value| Feature Importance (Top-{max_display})")
        plt.tight_layout()
        _save_fig(plt.gcf(), fig_dir, "07_shap_importance")

    except Exception as e:
        log.warning(f"SHAP analysis failed: {e}")


def plot_threshold_curve(y_true: np.ndarray, y_proba: np.ndarray,
                         optimal_t: float, fig_dir: str):
    thresholds = np.arange(0.05, 0.95, 0.01)
    f1s = [f1_score(y_true, (y_proba >= t).astype(int), zero_division=0)
           for t in thresholds]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(thresholds, f1s, color="#2196F3", lw=2, label="F1 (Illicit)")
    ax.axvline(optimal_t, color="red", linestyle="--",
               label=f"Optimal t={optimal_t:.2f}")
    ax.set_xlabel("Classification Threshold")
    ax.set_ylabel("F1 Score (Illicit Class)")
    ax.set_title("F1 Score vs. Classification Threshold — Hybrid Model")
    ax.legend()
    _save_fig(fig, fig_dir, "10_hybrid_threshold")


def plot_feature_stream_importance(shap_values: np.ndarray,
                                   feature_names: list, fig_dir: str):
    """Aggregate SHAP importance by feature stream."""
    stream_labels = {
        "pca_":   "Raw Features (PCA)",
        "sna_":   "SNA Graph",
        "n2v_":   "Node2Vec",
        "ts_":    "Temporal",
        "comm_":  "Community",
    }
    stream_importance = {v: 0.0 for v in stream_labels.values()}
    for i, fname in enumerate(feature_names):
        for prefix, label in stream_labels.items():
            if fname.startswith(prefix):
                stream_importance[label] += float(np.abs(shap_values[:, i]).mean())
                break

    streams = list(stream_importance.keys())
    values  = list(stream_importance.values())
    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(streams, values, color=PALETTE[:len(streams)])
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.001,
                f"{val:.3f}", ha="center", fontsize=9)
    ax.set_ylabel("Mean |SHAP Value|")
    ax.set_title("Feature Stream Contribution (SHAP-based)")
    plt.xticks(rotation=15, ha="right")
    _save_fig(fig, fig_dir, "09_feature_streams")


def plot_correlation_heatmap(X_test: np.ndarray, feature_names: list,
                             fig_dir: str, top_k: int = 15):
    """Plot correlation heatmap of the top-k features (assumes first k are most important)."""
    k = min(top_k, len(feature_names))
    X_subset = pd.DataFrame(X_test[:, :k], columns=feature_names[:k])
    corr = X_subset.corr()

    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
                square=True, linewidths=.5, cbar_kws={"shrink": .75})
    ax.set_title(f"Pearson Correlation Heatmap (Top {k} Features)", pad=20)
    plt.tight_layout()
    _save_fig(fig, fig_dir, "11_correlation_heatmap")


# ── Main evaluation ────────────────────────────────────────────────────────────

def run_full_evaluation(
    base_results: dict,
    stack_results: dict,
    hybrid_proba: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    feature_names: list,
    optimal_threshold: float,
    config_path: str = "config.yaml"
):
    cfg   = _load_config(config_path)
    paths = cfg["paths"]
    fg    = paths["figures_dir"]
    rp    = paths["reports_dir"]
    evcfg = cfg["evaluation"]
    os.makedirs(fg, exist_ok=True)
    os.makedirs(rp, exist_ok=True)

    model_names    = base_results["model_names"]
    trained_models = base_results["trained_models"]
    oof_test       = base_results["oof_test"]  # shape (n_test, n_models)

    # Build probabilities dict for all models
    all_probas = {}
    for i, name in enumerate(model_names):
        all_probas[name] = oof_test[:, i]
    all_probas["Stacked (MLP+LR)"] = stack_results["blend_proba_test"]
    all_probas["HYBRID (Final)"]   = hybrid_proba

    thresholds = {name: 0.5 for name in all_probas}
    thresholds["HYBRID (Final)"] = optimal_threshold

    # ── Compute metrics for all models ────────────────────────────────────────
    log.info("Computing metrics for all models…")
    metrics_list = []
    for name, proba in all_probas.items():
        t   = thresholds.get(name, 0.5)
        met = compute_metrics(y_test, proba, threshold=t, name=name)
        metrics_list.append(met)
        log.info(f"  {name:<25} F1={met['f1_illicit']:.4f}  "
                 f"AUC={met['auc_roc']:.4f}  MCC={met['mcc']:.4f}")

    metrics_df = pd.DataFrame(metrics_list)
    metrics_df.to_csv(f"{rp}/metrics_all_models.csv", index=False)
    log.info(f"Metrics table saved → {rp}/metrics_all_models.csv")

    # Generate LaTeX table
    latex_str = metrics_df.to_latex(
        index=False,
        float_format="%.4f",
        caption="Performance Comparison of Base Classifiers and the Hybrid Ensemble",
        label="tab:model_performance"
    )
    with open(f"{rp}/metrics_table.tex", "w") as f:
        f.write(latex_str)
    log.info(f"LaTeX table saved → {rp}/metrics_table.tex")

    # Full classification report for hybrid
    hybrid_pred = (hybrid_proba >= optimal_threshold).astype(int)
    report = classification_report(
        y_test, hybrid_pred,
        target_names=["Licit (0)", "Illicit (1)"],
        digits=4
    )
    with open(f"{rp}/evaluation_summary.txt", "w") as f:
        f.write("=" * 70 + "\n")
        f.write(" HYBRID FRAUD DETECTION SYSTEM — EVALUATION REPORT\n")
        f.write("=" * 70 + "\n\n")
        f.write("HYBRID MODEL — Classification Report:\n")
        f.write(report + "\n\n")
        f.write("ALL MODELS — Metrics Summary:\n")
        f.write(metrics_df.to_string(index=False) + "\n")
    log.info(f"Evaluation report saved → {rp}/evaluation_summary.txt")

    # ── Generate plots ────────────────────────────────────────────────────────
    log.info("Generating publication-quality plots…")
    plot_roc_curves(all_probas, y_test, fg)
    plot_pr_curves(all_probas, y_test, fg)
    plot_confusion_matrices(all_probas, y_test, thresholds, fg)
    plot_f1_comparison(metrics_list, fg)
    plot_threshold_curve(y_test, hybrid_proba, optimal_threshold, fg)
    plot_correlation_heatmap(X_test, feature_names, fg)

    # SHAP (on XGBoost base model)
    if "xgboost" in trained_models:
        plot_shap_analysis(
            trained_models["xgboost"],
            X_test, feature_names, fg,
            max_display=evcfg["shap_max_display"]
        )

    log.info("All evaluation plots saved.")

    return metrics_df


if __name__ == "__main__":
    log.info("Evaluation module loaded. Call run_full_evaluation().")
