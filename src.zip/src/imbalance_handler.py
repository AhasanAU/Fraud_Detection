"""
07_imbalance_handler.py
========================
Handle severe class imbalance in the Elliptic dataset (~10% illicit).

Strategy: SMOTE-ENN (combined over- and under-sampling)
- SMOTE: generates synthetic minority samples (illicit)
- ENN (Edited Nearest Neighbours): removes noisy majority/minority samples
  that are misclassified by their nearest neighbours

Important: Resampling is applied ONLY to the TRAINING set.
           The test set is kept in its original distribution.

Reports class distribution before and after resampling.
"""

import logging

import numpy as np
import pandas as pd
import yaml
from imblearn.combine import SMOTEENN
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import EditedNearestNeighbours
from collections import Counter

log = logging.getLogger("ImbalanceHandler")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)


def _load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def resample_training_data(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    config_path: str = "config.yaml"
) -> tuple:
    """
    Parameters
    ----------
    X_train : pd.DataFrame  — scaled feature matrix (training set)
    y_train : pd.Series     — training labels

    Returns
    -------
    X_res : np.ndarray  — resampled features
    y_res : np.ndarray  — resampled labels
    """
    cfg  = _load_config(config_path)
    imb  = cfg["imbalance"]
    seed = imb["random_state"]

    log.info("Class distribution BEFORE resampling:")
    c = Counter(y_train)
    total = len(y_train)
    for cls, cnt in sorted(c.items()):
        log.info(f"  Class {cls}: {cnt:,}  ({cnt/total*100:.1f}%)")
    imbalance_ratio = c[0] / c[1]
    log.info(f"  Imbalance ratio (licit:illicit): {imbalance_ratio:.1f}:1")

    method = imb["method"]

    if method == "smote_enn":
        log.info("Applying SMOTE-ENN (combined over+under sampling)…")
        smote = SMOTE(
            k_neighbors=imb["smote_k_neighbors"],
            random_state=seed,
            n_jobs=-1
        )
        enn = EditedNearestNeighbours(
            n_neighbors=imb["enn_n_neighbors"],
            n_jobs=-1
        )
        resampler = SMOTEENN(smote=smote, enn=enn, random_state=seed)

    elif method == "smote":
        log.info("Applying SMOTE (over-sampling only)…")
        resampler = SMOTE(
            k_neighbors=imb["smote_k_neighbors"],
            random_state=seed,
            n_jobs=-1
        )
    elif method == "adasyn":
        from imblearn.over_sampling import ADASYN
        log.info("Applying ADASYN…")
        resampler = ADASYN(random_state=seed, n_jobs=-1)
    else:
        log.warning(f"Unknown method '{method}' — skipping resampling.")
        return X_train.values, y_train.values

    X_res, y_res = resampler.fit_resample(X_train, y_train)

    log.info("Class distribution AFTER resampling:")
    c2 = Counter(y_res)
    total2 = len(y_res)
    for cls, cnt in sorted(c2.items()):
        log.info(f"  Class {cls}: {cnt:,}  ({cnt/total2*100:.1f}%)")
    log.info(f"  Total samples: {total:,} → {total2:,} (+{total2-total:,})")

    return X_res, y_res


def compute_scale_pos_weight(y_train: pd.Series) -> float:
    """Compute scale_pos_weight for XGBoost (ratio licit/illicit)."""
    c = Counter(y_train)
    ratio = c[0] / c[1]
    log.info(f"scale_pos_weight for XGBoost: {ratio:.2f}")
    return ratio


if __name__ == "__main__":
    log.info("Imbalance handler module loaded. Call resample_training_data().")
